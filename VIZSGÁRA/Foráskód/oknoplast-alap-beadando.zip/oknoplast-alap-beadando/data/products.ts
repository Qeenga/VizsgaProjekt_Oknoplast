export const products = [
  // Ablakok kategória
  {
    id: "koncept-70",
    name: "Koncept-70",
    category: "ablakok",
    subcategory: "muanyag",
    description:
      "Alapvető 5 kamrás profilrendszer kiváló ár-érték aránnyal. Ideális választás családi házakhoz és lakásokhoz, ahol a megbízhatóság és az energiahatékonyság a fő szempont.",
    image_src: "/images/oknoplast-windows.jpg",
    link: "/termekeink/koncept-70",
    specifications: {
      kamraszam: "5 kamrás",
      Uw: "1,1 W/m²K",
      beepitesi_melyseg: "70 mm",
      biztonsag: "RC2",
      hangszigeteles: "32 dB",
      profil: "5 kamrás",
      uvegezés: "2 rétegű",
      design: "Alapvető, megbízható",
    },
    price_range: "budget",
    is_active: true,
    sort_order: 1,
  },
  {
    id: "prolux-70",
    name: "Prolux-70",
    category: "ablakok",
    subcategory: "muanyag",
    description:
      "Prémium 6 kamrás profilrendszer fokozott hőszigetelési tulajdonságokkal. Modern design és kiváló funkcionalitás jellemzi, tökéletes választás igényes otthonokhoz.",
    image_src: "/images/oknoplast-window-anthracite.png",
    link: "/termekeink/prolux-70",
    specifications: {
      kamraszam: "6 kamrás",
      Uw: "0,9 W/m²K",
      beepitesi_melyseg: "70 mm",
      biztonsag: "RC2",
      hangszigeteles: "35 dB",
      profil: "6 kamrás",
      uvegezés: "2 rétegű",
      design: "Prémium, modern",
    },
    price_range: "mid",
    is_active: true,
    sort_order: 2,
  },
  {
    id: "winergetic-82",
    name: "Winergetic-82",
    category: "ablakok",
    subcategory: "muanyag",
    description:
      "Az Oknoplast zászlóshajó profilrendszere, amely a legmodernebb technológiákat ötvözi egyetlen profilrendszerben. A 7 kamrás szerkezet és a Termo HS technológia révén kiváló energiahatékonyságot és hosszú élettartamot biztosít minden típusú épülethez.",
    image_src: "/images/okna-dom-parterowy-oknoplast.jpg",
    link: "/termekeink/winergetic-82",
    specifications: {
      kamraszam: "7 kamrás",
      Uw: "0,6 W/m²K",
      beepitesi_melyseg: "82 mm",
      biztonsag: "RC2+",
      hangszigeteles: "42 dB",
      profil: "7 kamrás",
      uvegezés: "3 rétegű",
      design: "Modern építészet",
      technologia: "Termo HS",
    },
    price_range: "premium",
    is_active: true,
    sort_order: 3,
  },
  // Redőnyök kategória
  {
    id: "alu-redony",
    name: "Alu Redőny",
    category: "redonyok",
    subcategory: "kulso",
    description: "Különböző típusú redőnyök a tökéletes árnyékolásért.",
    image_src: "/images/jakie-okna-do-domu-parterowego.jpg",
    link: "/kapcsolat",
    specifications: {
      anyag: "Alumínium",
      szigeteles: "Közepes",
      motoros: "Igen",
      szinvalasztek: "Széles",
      lamella: "55mm",
      vezerlés: "Távirányító",
    },
    price_range: "mid",
    is_active: true,
    sort_order: 1,
  },
  {
    id: "muanyag-redony",
    name: "Műanyag Redőny",
    category: "redonyok",
    subcategory: "kulso",
    description: "Praktikus műanyag redőnyök megfizethető áron.",
    image_src: "/images/oknoplast-hero.jpg",
    link: "/kapcsolat",
    specifications: {
      anyag: "PVC",
      szigeteles: "Jó",
      motoros: "Nem",
      szinvalasztek: "Korlátozott",
      lamella: "50mm",
      vezerlés: "Kézi",
    },
    price_range: "budget",
    is_active: true,
    sort_order: 2,
  },
  // Kiegészítők kategória
  {
    id: "szunyoghalok",
    name: "Szúnyoghálók",
    category: "accessories",
    subcategory: "kiegeszito",
    description: "Praktikus szúnyoghálók ablakokra és ajtókra.",
    image_src: "/images/oknoplast-hero.jpg",
    link: "/kapcsolat",
    specifications: {
      anyag: "Finom szövés",
      tisztitas: "Könnyen tisztítható",
      tartossag: "Tartós anyag",
      meretek: "Egyedi méretek",
    },
    price_range: "budget",
    is_active: true,
    sort_order: 1,
  },
  {
    id: "parkanyok",
    name: "Párkányok",
    category: "accessories",
    subcategory: "kiegeszito",
    description: "Kül- és beltéri párkányok széles választékban.",
    image_src: "/images/hero-background.jpg",
    link: "/kapcsolat",
    specifications: {
      anyagok: "Különböző anyagok",
      idojarasallo: "Időjárásálló",
      meretek: "Egyedi méretek",
      szereles: "Könnyű szerelés",
    },
    price_range: "budget",
    is_active: true,
    sort_order: 2,
  },
]

export const curvedWindows = [
  {
    name: "Félkör Ív",
    description:
      "Elegáns félkör alakú ablakok, amelyek különleges építészeti hangsúlyt adnak az épületnek. Ideális választás klasszikus és modern stílusokhoz egyaránt.",
    features: ["Félkör alakú design", "Egyedi gyártás", "Minden profilrendszerrel", "Speciális üvegezés"],
  },
  {
    name: "Háromszög",
    description:
      "Háromszög alakú ablakok tetőtéri és különleges építészeti megoldásokhoz. Tökéletes választás modern és kortárs épületekhez.",
    features: ["Háromszög alakú", "Tetőtéri alkalmazás", "Egyedi szögek", "Precíz illesztés"],
  },
  {
    name: "Íves",
    description:
      "Különböző ívelt formájú ablakok, amelyek egyedi karaktert adnak az épületnek. Személyre szabott megoldások minden építészeti igényhez.",
    features: ["Változatos ívek", "Egyedi tervezés", "Építészeti kiemelés", "Prémium kivitelezés"],
  },
  {
    name: "Íves negyed",
    description:
      "Negyedkör alakú ablakok, amelyek tökéletes megoldást nyújtanak sarokablakok és különleges építészeti részletekhez.",
    features: ["Negyedkör alakú", "Sarok megoldások", "Speciális illesztés", "Egyedi gyártás"],
  },
  {
    name: "Kerek",
    description:
      "Teljesen kerek ablakok, amelyek különleges vizuális hatást keltenek. Ideális választás modern és avantgárd építészeti stílusokhoz.",
    features: ["Teljesen kerek forma", "Egyedi gyártás", "Speciális vasalatok", "Modern design"],
  },
  {
    name: "Trapéz négyszög",
    description:
      "Trapéz alakú négyszög ablakok, amelyek dinamikus megjelenést biztosítanak kortárs építészeti megoldásokhoz.",
    features: ["Trapéz alakú", "4 oldal", "Dinamikus design", "Egyedi szögek"],
  },
  {
    name: "Trapéz ötszög",
    description:
      "Ötszög alakú trapéz ablakok különleges geometriai formával. Egyedi építészeti megoldásokhoz ideális választás.",
    features: ["Trapéz alakú", "5 oldal", "Komplex geometria", "Speciális tervezés"],
  },
  {
    name: "Trapéz hatszög",
    description:
      "Hatszög alakú trapéz ablakok a legkomplexebb geometriai megoldásokhoz. Különleges építészeti kiemelések létrehozásához.",
    features: ["Trapéz alakú", "6 oldal", "Komplex forma", "Egyedi kivitelezés"],
  },
]

export type Product = {
  id: string
  name: string
  category: "ablakok" | "ajtok" | "redonyok" | "accessories"
  subcategory?: string
  description: string
  image_src: string
  link: string
  specifications: Record<string, any>
  price_range: "budget" | "mid" | "premium"
  is_active: boolean
  sort_order: number
}

export type CurvedWindow = {
  name: string
  description: string
  features: string[]
}
