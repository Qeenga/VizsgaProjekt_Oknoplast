"use client"

import { useState, useEffect } from "react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useProductsByCategory } from "@/hooks/use-products"
import type { Product } from "@/lib/product-utils"

const categoryLabels = {
  ablakok: "Ablakok",
  ajtok: "Ajtók",
  redonyok: "Redőnyök",
  accessories: "Kiegészítők",
}

const propertyLabels: { [key: string]: string } = {
  Uw: "Hőszigetelés (Uw)",
  Ud: "Hőszigetelés (Ud)",
  hangszigeteles: "Hangszigetelés",
  profil: "Profil típus",
  uvegezés: "Üvegezés",
  biztonsag: "Biztonság",
  design: "Design",
  anyag: "Anyag",
  hoszigeteles: "Hőszigetelés",
  vastagság: "Vastagság",
  szinvalasztek: "Színválaszték",
  szigeteles: "Szigetelés",
  motoros: "Motoros",
  lamella: "Lamella méret",
  vezerlés: "Vezérlés",
  kamraszam: "Kamraszám",
  beepitesi_melyseg: "Beépítési mélység",
  technologia: "Technológia",
}

export default function ProductComparison() {
  const { productsByCategory, loading, error } = useProductsByCategory()
  const [selectedCategory, setSelectedCategory] = useState<string>("ablakok")
  const [product1, setProduct1] = useState<string>("")
  const [product2, setProduct2] = useState<string>("")

  const availableCategories = Object.keys(productsByCategory).filter((cat) => productsByCategory[cat].length > 1)

  useEffect(() => {
    if (productsByCategory[selectedCategory]?.length > 0) {
      const products = productsByCategory[selectedCategory]
      setProduct1(products[0]?.id || "")
      setProduct2(products[1]?.id || products[0]?.id || "")
    }
  }, [selectedCategory, productsByCategory])

  const getProductsForCategory = (category: string): Product[] => {
    return productsByCategory[category] || []
  }

  const getComparisonData = () => {
    if (!product1 || !product2 || !productsByCategory[selectedCategory]) return null

    const products = productsByCategory[selectedCategory]
    const p1 = products.find((p) => p.id === product1)
    const p2 = products.find((p) => p.id === product2)

    if (!p1 || !p2) return null

    // Get all specification keys from both products
    const allKeys = new Set([...Object.keys(p1.specifications || {}), ...Object.keys(p2.specifications || {})])
    const properties = Array.from(allKeys)

    return { p1, p2, properties }
  }

  const comparisonData = getComparisonData()

  if (loading) {
    return (
      <section className="max-w-6xl mx-auto p-4 md:p-8 bg-gray-50 rounded-lg">
        <div className="text-center">
          <p>Termékek betöltése...</p>
        </div>
      </section>
    )
  }

  if (error) {
    return (
      <section className="max-w-6xl mx-auto p-4 md:p-8 bg-gray-50 rounded-lg">
        <div className="text-center text-red-600">
          <p>Hiba történt a termékek betöltése során: {error}</p>
        </div>
      </section>
    )
  }

  return (
    <section className="max-w-6xl mx-auto p-4 md:p-8 bg-gray-50 rounded-lg">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-4">Termék összehasonlító</h2>
        <p className="text-gray-600 mb-8">Válasszon kategóriát és két terméket az összehasonlításhoz!</p>
      </div>

      {/* Vezérlők */}
      <div className="flex flex-col md:flex-row items-center justify-center gap-4 mb-8 p-4 bg-white rounded-lg shadow-md">
        <div className="flex flex-col">
          <label className="font-semibold text-sm mb-2">Kategória:</label>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {availableCategories.map((key) => (
                <SelectItem key={key} value={key}>
                  {categoryLabels[key as keyof typeof categoryLabels] || key}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col">
          <label className="font-semibold text-sm mb-2">Termék 1:</label>
          <Select value={product1} onValueChange={setProduct1}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {getProductsForCategory(selectedCategory).map((product) => (
                <SelectItem key={product.id} value={product.id}>
                  {product.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col">
          <label className="font-semibold text-sm mb-2">Termék 2:</label>
          <Select value={product2} onValueChange={setProduct2}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {getProductsForCategory(selectedCategory).map((product) => (
                <SelectItem key={product.id} value={product.id}>
                  {product.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Összehasonlító táblázat */}
      {comparisonData && (
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-primary text-white">
                  <th className="p-4 text-left font-semibold">Tulajdonság</th>
                  <th className="p-4 text-center font-semibold">{comparisonData.p1.name}</th>
                  <th className="p-4 text-center font-semibold">{comparisonData.p2.name}</th>
                </tr>
              </thead>
              <tbody>
                {comparisonData.properties.map((property) => (
                  <tr key={property} className="border-b hover:bg-gray-50">
                    <td className="p-4 font-semibold bg-gray-100">{propertyLabels[property] || property}</td>
                    <td className="p-4 text-center">{comparisonData.p1.specifications?.[property] || "-"}</td>
                    <td className="p-4 text-center">{comparisonData.p2.specifications?.[property] || "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {!comparisonData && (
        <div className="text-center py-12 text-gray-500 bg-white rounded-lg">
          <p>Válasszon ki két terméket az összehasonlításhoz!</p>
        </div>
      )}
    </section>
  )
}
