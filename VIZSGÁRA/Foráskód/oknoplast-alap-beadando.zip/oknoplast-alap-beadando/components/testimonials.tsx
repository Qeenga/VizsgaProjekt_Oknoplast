import { Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function Testimonials() {
  return (
    <div className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title inline-block">Ügyfeleink véleménye</h2>
          <p className="max-w-2xl mx-auto mt-4">Valós Google vélemények elégedett ügyfeleink tapasztalatairól.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="h-full">
            <CardContent className="pt-6">
              <div className="flex mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-[#FFD700] fill-[#FFD700]" />
                ))}
              </div>
              <p className="italic mb-4">
                "Időtálló, minőségi termékek, amik sok év után is tökéletesen működnek. Udvarias, kedves és teljeskörű
                kiszolgálás. Sok éve már az első házunk nyílászáróit is az Oknoplast-tól vettük és a mostanit is. Most
                sem döntenék másképp. Mindenkinek szívből ajánlom!"
              </p>
              <p className="font-bold">Anikó Liptai</p>
              <p className="text-sm text-gray-500">Google vélemény • 2 hónapja</p>
            </CardContent>
          </Card>

          <Card className="h-full">
            <CardContent className="pt-6">
              <div className="flex mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-[#FFD700] fill-[#FFD700]" />
                ))}
              </div>
              <p className="italic mb-4">
                "Abszolút határidőn belül jöttek, nagyon segítőkész csapat. Ablak, teraszajtó berakás volt nálunk,
                problémamentes és gyors munka volt. Ajánlom őket"
              </p>
              <p className="font-bold">Dániel Puskás</p>
              <p className="text-sm text-gray-500">Google vélemény • 3 hónapja</p>
            </CardContent>
          </Card>

          <Card className="h-full">
            <CardContent className="pt-6">
              <div className="flex mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-[#FFD700] fill-[#FFD700]" />
                ))}
              </div>
              <p className="italic mb-4">
                "Legprofibb ablakos Debrecenben! Leggyorsabban válaszolnak, kijönnek felmérni a pontos méreteket és
                minden ablak ajtóval kapcsolatos munkát is vállalnak garanciával 👌"
              </p>
              <p className="font-bold">Gergely Kovács</p>
              <p className="text-sm text-gray-500">Google vélemény • 3 hónapja</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="h-full">
            <CardContent className="pt-6">
              <div className="flex mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-[#FFD700] fill-[#FFD700]" />
                ))}
              </div>
              <p className="italic mb-4">
                "Nagyon igényes, precíz munka. Megbízhatóak, tartják a megbeszélt határidőt. Én csak ajánlani tudom :)"
              </p>
              <p className="font-bold">Virág Puskás-Szaniszló</p>
              <p className="text-sm text-gray-500">Google vélemény • 3 hónapja</p>
            </CardContent>
          </Card>

          <Card className="h-full">
            <CardContent className="pt-6">
              <div className="flex mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 text-[#FFD700] fill-[#FFD700]" />
                ))}
              </div>
              <p className="italic mb-4">
                "Some of the most CUSTOMER CENTRIC people I have ever met. They are absolutely the BEST in SERVICE and
                TOP QUALITY products!"
              </p>
              <p className="font-bold">Janos Papai</p>
              <p className="text-sm text-gray-500">Google vélemény • 7 éve</p>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <div className="bg-white p-6 rounded-lg shadow-md inline-block">
            <div className="flex items-center justify-center mb-2">
              <div className="flex mr-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-6 w-6 text-[#FFD700] fill-[#FFD700]" />
                ))}
              </div>
              <span className="text-2xl font-bold text-primary">5.0</span>
            </div>
            <p className="text-gray-600 mb-2">18+ Google vélemény alapján</p>
            <a
              href="https://www.google.com/search?q=oknoplast+debrecen+vélemények"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:text-accent transition-colors font-semibold"
            >
              Összes vélemény megtekintése →
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
