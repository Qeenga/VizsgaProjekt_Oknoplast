import Image from "next/image"
import Link from "next/link"

export default function Introduction() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="section-title mb-6">Üdvözöljük az Oknoplast Debrecen-ben!</h2>
            <p className="text-lg mb-6">
              Több mint 10 éve vagyunk jelen a debreceni nyílászáró piacon, és büszkén képviseljük az Oknoplast márka
              értékeit. Cégünk elkötelezett a minőség, a megbízhatóság és az ügyfélközpontúság mellett.
            </p>
            <p className="mb-6">
              Szakértő csapatunk segít megtalálni a tökéletes nyílászáró megoldást az Ön otthonához. Legyen szó
              ablakokról, ajtókról vagy kiegészítőkről, mi minden lépésben támogatjuk Önt - a tanácsadástól a
              telepítésig.
            </p>
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">500+</div>
                <div className="text-sm text-gray-600">Elégedett ügyfél</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">10+</div>
                <div className="text-sm text-gray-600">Év tapasztalat</div>
              </div>
            </div>
            <Link href="/rolunk" className="btn-secondary">
              Tudjon meg többet rólunk
            </Link>
          </div>

          <div className="relative h-[500px] rounded-lg overflow-hidden shadow-xl">
            <Image
              src="https://oknoplast.hu/content/uploads/2019/10/salon_sprzedazy_oknoplast-1440x940.jpg"
              alt="Oknoplast Debrecen - Minőségi nyílászárók"
              fill
              className="object-cover"
              crossOrigin="anonymous"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
