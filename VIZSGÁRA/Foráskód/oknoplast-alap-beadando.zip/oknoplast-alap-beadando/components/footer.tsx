import Link from "next/link"
import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">Oknoplast Debrecen</h3>
            <p className="text-gray-300 mb-4">
              Prémium műanyag ablakok, ajtók és redőnyök Debrecenben. Több mint 15 éves tapasztalat és több ezer
              elégedett ügyfél.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                <Youtube className="w-5 h-5" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Gyors linkek</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white transition-colors">
                  Főoldal
                </Link>
              </li>
              <li>
                <Link href="/termekeink" className="text-gray-300 hover:text-white transition-colors">
                  Termékeink
                </Link>
              </li>
              <li>
                <Link href="/szolgaltatasok" className="text-gray-300 hover:text-white transition-colors">
                  Szolgáltatások
                </Link>
              </li>
              <li>
                <Link href="/rolunk" className="text-gray-300 hover:text-white transition-colors">
                  Rólunk
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-300 hover:text-white transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/kapcsolat" className="text-gray-300 hover:text-white transition-colors">
                  Kapcsolat
                </Link>
              </li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h3 className="text-xl font-bold mb-4">Termékeink</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/termekeink" className="text-gray-300 hover:text-white transition-colors">
                  Műanyag ablakok
                </Link>
              </li>
              <li>
                <Link href="/termekeink" className="text-gray-300 hover:text-white transition-colors">
                  Bejárati ajtók
                </Link>
              </li>
              <li>
                <Link href="/termekeink" className="text-gray-300 hover:text-white transition-colors">
                  Teraszajtók
                </Link>
              </li>
              <li>
                <Link href="/termekeink" className="text-gray-300 hover:text-white transition-colors">
                  Redőnyök
                </Link>
              </li>
              <li>
                <Link href="/termekeink" className="text-gray-300 hover:text-white transition-colors">
                  Kiegészítők
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">Elérhetőség</h3>
            <div className="space-y-3">
              <div className="flex items-center">
                <MapPin className="w-5 h-5 mr-3 text-accent" />
                <div>
                  <p className="text-gray-300">4025 Debrecen</p>
                  <p className="text-gray-300">Példa utca 123.</p>
                </div>
              </div>
              <div className="flex items-center">
                <Phone className="w-5 h-5 mr-3 text-accent" />
                <Link href="tel:+36301234567" className="text-gray-300 hover:text-white transition-colors">
                  +36 30 123 4567
                </Link>
              </div>
              <div className="flex items-center">
                <Mail className="w-5 h-5 mr-3 text-accent" />
                <Link
                  href="mailto:info@oknoplast-debrecen.hu"
                  className="text-gray-300 hover:text-white transition-colors"
                >
                  info@oknoplast-debrecen.hu
                </Link>
              </div>
              <div className="flex items-center">
                <Clock className="w-5 h-5 mr-3 text-accent" />
                <div>
                  <p className="text-gray-300">H-P: 8:00-17:00</p>
                  <p className="text-gray-300">Szo: 8:00-12:00</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-300">
            © 2024 Oknoplast Debrecen. Minden jog fenntartva. |{" "}
            <Link href="/adatvedelmi-nyilatkozat" className="hover:text-white transition-colors">
              Adatvédelmi nyilatkozat
            </Link>{" "}
            |{" "}
            <Link href="/aszf" className="hover:text-white transition-colors">
              ÁSZF
            </Link>
          </p>
        </div>
      </div>
    </footer>
  )
}
