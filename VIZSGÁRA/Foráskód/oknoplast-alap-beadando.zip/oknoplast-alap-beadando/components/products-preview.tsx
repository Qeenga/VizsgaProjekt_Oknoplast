"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { useProductsByCategory } from "@/hooks/use-products"

export default function ProductsPreview() {
  const { productsByCategory, loading, error } = useProductsByCategory()

  if (loading) {
    return (
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <p>Termékek betöltése...</p>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center text-red-600">
            <p>Hiba történt a termékek betöltése során.</p>
          </div>
        </div>
      </div>
    )
  }

  const categories = [
    {
      key: "ablakok",
      title: "Ablakok",
      description: "Modern műanyag és alumínium ablakok széles választéka.",
      defaultImage: "/https://oknoplast.hu/content/uploads/2025/06/324234.webp",
    },
    {
      key: "ajtok",
      title: "Ajtók",
      description: "Beltéri és kültéri ajtók, biztonsági és dizájn megoldások.",
      defaultImage: "/https://oknoplast.hu/content/uploads/2023/05/drzwi-pvc-basic-12-920x721.jpg",
    },
    {
      key: "redonyok",
      title: "Redőnyök & Kiegészítők",
      description: "Árnyékolók, szúnyoghálók, párkányok és egyéb kiegészítők.",
      defaultImage: "/https://oknoplast.hu/content/uploads/2023/07/terra-antracyt-5223-920x920.png",
    },
  ]

  return (
    <div className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="section-title inline-block">Termékeink</h2>
          <p className="max-w-2xl mx-auto mt-4">
            Fedezze fel prémium minőségű nyílászáróink széles választékát, amelyek tökéletes megoldást nyújtanak minden
            otthon számára.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {categories.map((category) => {
            const products = productsByCategory[category.key] || []
            const count = products.length
            const featuredProduct = products[0]

            return (
              <ProductCategory
                key={category.key}
                title={`${category.title} (${count})`}
                description={category.description}
                imageSrc={featuredProduct?.image_src || category.defaultImage}
                link="/termekeink"
              />
            )
          })}
        </div>

        <div className="text-center">
          <Link href="/termekeink" className="btn-primary">
            Összes termék megtekintése
          </Link>
        </div>
      </div>
    </div>
  )
}

function ProductCategory({
  title,
  description,
  imageSrc,
  link,
}: { title: string; description: string; imageSrc: string; link: string }) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md transition-transform duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative h-64">
        <Image src={imageSrc || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-[#003366] mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <Link
          href={link}
          className="flex items-center text-[#003366] font-semibold hover:text-[#FFD700] transition-colors"
        >
          Részletek
          <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
      </div>
    </div>
  )
}
