import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Wrench, Truck, Shield, Clock, MapPin, Users } from "lucide-react"
import Link from "next/link"

const services = [
  {
    title: "Ingyenes Helyszíni Felmérés",
    description: "Szakértő csapatunk ingyenesen felméri otthonát és személyre szabott ajánlatot készít.",
    icon: MapPin,
    color: "bg-green-50 border-green-200",
  },
  {
    title: "Professzionális Beépítés",
    description: "Tapasztalt szerelőink gondoskodnak a szakszerű és precíz beépítésről.",
    icon: Wrench,
    color: "bg-blue-50 border-blue-200",
  },
  {
    title: "Szállítás és Logisztika",
    description: "Gondoskodunk a termékek biztonságos szállításáról és időben történő kiszállításáról.",
    icon: Truck,
    color: "bg-purple-50 border-purple-200",
  },
  {
    title: "Hosszú Távú Garancia",
    description: "Minden termékünkre és szolgáltatásunkra kiterjedő, hosszú távú garanciát vállalunk.",
    icon: Shield,
    color: "bg-orange-50 border-orange-200",
  },
  {
    title: "Gyors Ügyintézés",
    description: "Hatékony folyamatainknak köszönhetően gyorsan és zökkenőmentesen intézzük megrendelését.",
    icon: Clock,
    color: "bg-red-50 border-red-200",
  },
  {
    title: "Ügyfélszolgálat",
    description: "Kiváló ügyfélszolgálatunk minden lépésben támogatja Önt a vásárlási folyamat során.",
    icon: Users,
    color: "bg-teal-50 border-teal-200",
  },
]

export default function ServicesPreview() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Szolgáltatásaink</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Teljes körű szolgáltatást nyújtunk a tervezéstől a beépítésig. Tapasztalt csapatunk minden lépésben
            támogatja Önt.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {services.map((service, index) => {
            const IconComponent = service.icon
            return (
              <Card key={index} className={`${service.color} hover:shadow-lg transition-shadow`}>
                <CardHeader>
                  <IconComponent className="w-12 h-12 text-primary mb-4" />
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription className="text-gray-600">{service.description}</CardDescription>
                </CardHeader>
              </Card>
            )
          })}
        </div>

        <div className="text-center">
          <Button size="lg" asChild>
            <Link href="/szolgaltatasok">Összes Szolgáltatás</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
