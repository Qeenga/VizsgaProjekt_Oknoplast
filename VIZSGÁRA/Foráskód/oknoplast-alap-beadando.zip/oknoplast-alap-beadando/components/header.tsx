"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Phone, Mail, Menu, X } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  const navigation = [
    { name: "Főoldal", href: "/" },
    { name: "Termékeink", href: "/termekeink" },
    { name: "Szolgáltatások", href: "/szolgaltatasok" },
    { name: "Rólunk", href: "/rolunk" },
    { name: "Blog", href: "/blog" },
    { name: "Kapcsolat", href: "/kapcsolat" },
  ]

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white shadow-md">
      {/* Top Contact Bar */}
      <div className="bg-primary text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center text-sm">
            {/* Left side - Phone */}
            <div className="flex items-center space-x-2">
              <Phone className="h-4 w-4" />
              <a href="tel:+36301234567" className="hover:text-accent transition-colors">
                +36 30 123 4567
              </a>
            </div>

            {/* Right side - Email */}
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4" />
              <a href="mailto:info@oknoplast-debrecen.hu" className="hover:text-accent transition-colors">
                info@oknoplast-debrecen.hu
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold text-primary">Oknoplast Debrecen</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`text-gray-700 hover:text-primary transition-colors font-medium ${
                    pathname === item.href ? "text-primary border-b-2 border-accent" : ""
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={toggleMenu}
              className="lg:hidden p-2 rounded-md text-gray-700 hover:text-primary hover:bg-gray-100 transition-colors"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-200 shadow-lg">
            <div className="container mx-auto px-4">
              <nav className="py-4 max-h-80 overflow-y-auto">
                <div className="space-y-2">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      onClick={() => setIsMenuOpen(false)}
                      className={`block px-4 py-3 rounded-md text-gray-700 hover:text-primary hover:bg-gray-50 transition-colors font-medium ${
                        pathname === item.href ? "text-primary bg-gray-50 border-l-4 border-accent" : ""
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </nav>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
