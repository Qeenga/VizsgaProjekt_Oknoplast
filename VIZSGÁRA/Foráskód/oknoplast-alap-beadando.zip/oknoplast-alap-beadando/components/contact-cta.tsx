import { Button } from "@/components/ui/button"
import { Phone, Mail, MapPin } from "lucide-react"
import Link from "next/link"

export default function ContactCTA() {
  return (
    <section className="py-16 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Készen áll az első lépésre?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Vegye fel velünk a kapcsolatot még ma, és kérjen ingyenes helyszíni felmérést és ajánlatot!
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="text-center">
            <Phone className="w-12 h-12 mx-auto mb-4" />
            <h3 className="text-lg font-bold mb-2">Telefonon</h3>
            <p className="mb-4">Hívjon minket munkaidőben</p>
            <Button variant="secondary" asChild>
              <Link href="tel:+36301234567">+36 30 123 4567</Link>
            </Button>
          </div>

          <div className="text-center">
            <Mail className="w-12 h-12 mx-auto mb-4" />
            <h3 className="text-lg font-bold mb-2">E-mailben</h3>
            <p className="mb-4">Írjon nekünk bármikor</p>
            <Button variant="secondary" asChild>
              <Link href="mailto:info@oknoplast-debrecen.hu">E-mail küldése</Link>
            </Button>
          </div>

          <div className="text-center">
            <MapPin className="w-12 h-12 mx-auto mb-4" />
            <h3 className="text-lg font-bold mb-2">Személyesen</h3>
            <p className="mb-4">Látogasson el bemutatótermünkbe</p>
            <Button variant="secondary" asChild>
              <Link href="/kapcsolat">Útvonalterv</Link>
            </Button>
          </div>
        </div>

        <div className="text-center">
          <Button size="lg" variant="secondary" asChild>
            <Link href="/kapcsolat">Kapcsolatfelvétel</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
