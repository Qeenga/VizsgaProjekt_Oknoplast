"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import type { Product } from "@/lib/product-utils"

export function useProducts(category?: string) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchProducts() {
      try {
        setLoading(true)
        const supabase = createClient()
        let query = supabase.from("products").select("*").eq("is_active", true).order("sort_order", { ascending: true })

        if (category) {
          query = query.eq("category", category)
        }

        const { data, error } = await query

        if (error) {
          throw error
        }

        setProducts(data || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred")
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [category])

  return { products, loading, error }
}

export function useProductsByCategory() {
  const [productsByCategory, setProductsByCategory] = useState<Record<string, Product[]>>({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchProducts() {
      try {
        setLoading(true)
        const supabase = createClient()
        const { data, error } = await supabase
          .from("products")
          .select("*")
          .eq("is_active", true)
          .order("sort_order", { ascending: true })

        if (error) {
          throw error
        }

        // Group products by category
        const grouped = (data || []).reduce(
          (acc, product) => {
            if (!acc[product.category]) {
              acc[product.category] = []
            }
            acc[product.category].push(product)
            return acc
          },
          {} as Record<string, Product[]>,
        )

        setProductsByCategory(grouped)
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred")
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [])

  return { productsByCategory, loading, error }
}
