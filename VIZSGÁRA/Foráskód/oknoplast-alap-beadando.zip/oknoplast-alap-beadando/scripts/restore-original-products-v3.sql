-- Restore original Oknoplast products to database
-- This script adds the complete product catalog with proper categories

-- Clear existing products first
DELETE FROM products;

-- Insert Ablakok (Windows)
INSERT INTO products (id, name, description, category, price_range, image_src, link, specifications, is_active, sort_order) VALUES
(gen_random_uuid(), 'Koncept-70', 'Kiváló ár-érték arányú műanyag ablak 70mm-es profilmélységgel. Ideális választás családi házakhoz és lakásokhoz, modern technológiával és megbízható minőséggel.', 'ablakok', 'Közép kategória', '/images/koncept-70-ablak.jpg', '/termekeink/koncept-70', '{"Profilmélység": "70 mm", "Kamrák száma": "5 kamra", "Hőszigetelés": "Uw = 1,3 W/m²K", "Hangszigetelés": "Rw = 32 dB", "Üvegezés": "Dupla üveg", "Garancia": "10 év"}', true, 1),

(gen_random_uuid(), 'Prolux-70', 'Prémium minőségű műanyag ablak fokozott hőszigetelési tulajdonságokkal. Energiatakarékos megoldás passzívházakhoz és alacsony energiaigényű épületekhez.', 'ablakok', 'Prémium kategória', '/images/prolux-70-ablak.jpg', '/termekeink/prolux-70', '{"Profilmélység": "70 mm", "Kamrák száma": "6 kamra", "Hőszigetelés": "Uw = 1,1 W/m²K", "Hangszigetelés": "Rw = 35 dB", "Üvegezés": "Háromrétegű üveg", "Garancia": "15 év"}', true, 2),

(gen_random_uuid(), 'Winergetic-82', 'Csúcskategóriás műanyag ablak 82mm-es profilmélységgel. Passzívház szabványnak megfelelő hőszigetelés és kiváló hangszigetelési tulajdonságok.', 'ablakok', 'Prémium kategória', '/images/winergetic-82-ablak.jpg', '/termekeink/winergetic-82', '{"Profilmélység": "82 mm", "Kamrák száma": "7 kamra", "Hőszigetelés": "Uw = 0,9 W/m²K", "Hangszigetelés": "Rw = 38 dB", "Üvegezés": "Háromrétegű üveg", "Garancia": "20 év"}', true, 3);

-- Insert Redőnyök (Shutters)
INSERT INTO products (id, name, description, category, price_range, image_src, link, specifications, is_active, sort_order) VALUES
(gen_random_uuid(), 'Alumínium redőny', 'Tartós alumínium redőny kiváló árnyékolási tulajdonságokkal. Különböző színekben és méretekben elérhető, hosszú élettartammal.', 'redonyok', 'Közép kategória', '/images/aluminium-redony.jpg', '/kapcsolat', '{"Anyag": "Extrudált alumínium", "Lamella vastagság": "14 mm", "Színek": "RAL színskála", "Vezérlés": "Kézi vagy motoros", "Garancia": "10 év"}', true, 1),

(gen_random_uuid(), 'PVC redőny', 'Költséghatékony PVC redőny megoldás. Könnyű, karbantartásmentes és kiváló hőszigetelési tulajdonságokkal rendelkezik.', 'redonyok', 'Alapvető kategória', '/images/pvc-redony.jpg', '/kapcsolat', '{"Anyag": "PVC", "Lamella vastagság": "12 mm", "Színek": "Fehér, barna, antracit", "Vezérlés": "Kézi", "Garancia": "5 év"}', true, 2),

(gen_random_uuid(), 'Biztonsági redőny', 'Megerősített biztonsági redőny betörésvédelemmel. Fokozott biztonságot nyújt otthonának és értékeinek védelmére.', 'redonyok', 'Prémium kategória', '/images/biztonsagi-redony.jpg', '/kapcsolat', '{"Anyag": "Megerősített alumínium", "Lamella vastagság": "17 mm", "Biztonsági osztály": "RC2", "Vezérlés": "Motoros", "Garancia": "15 év"}', true, 3);

-- Insert Accessories
INSERT INTO products (id, name, description, category, price_range, image_src, link, specifications, is_active, sort_order) VALUES
(gen_random_uuid(), 'Szúnyogháló', 'Praktikus szúnyogháló megoldások ablakokhoz és ajtókhoz. Különböző típusokban: fix, rolós és pliszé változatban.', 'accessories', 'Alapvető kategória', '/images/szunyoghalo.jpg', '/kapcsolat', '{"Típusok": "Fix, rolós, pliszé", "Anyag": "Fiberglass háló", "Keret": "Alumínium", "Színek": "Fehér, barna, antracit", "Garancia": "3 év"}', true, 1),

(gen_random_uuid(), 'Ablakpárkány', 'Belső és külső ablakpárkányok széles választéka. Műanyag, alumínium és természetes kő kivitelben.', 'accessories', 'Közép kategória', '/images/ablakparkany.jpg', '/kapcsolat', '{"Típusok": "Belső, külső", "Anyagok": "PVC, alumínium, kő", "Színek": "RAL színskála", "Vastagság": "20-40 mm", "Garancia": "10 év"}', true, 2),

(gen_random_uuid(), 'Árnyékolók', 'Modern árnyékoló megoldások: külső és belső árnyékolók, napellenzők és pergolák.', 'accessories', 'Prémium kategória', '/images/arnyekolok.jpg', '/kapcsolat', '{"Típusok": "Külső, belső árnyékoló", "Anyag": "Alumínium, textil", "Vezérlés": "Kézi, motoros", "Színek": "Széles választék", "Garancia": "5-10 év"}', true, 3);

-- Update the sequence for proper ordering
SELECT setval(pg_get_serial_sequence('products', 'sort_order'), (SELECT MAX(sort_order) FROM products));
