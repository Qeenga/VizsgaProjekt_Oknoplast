-- Setup storage bucket and policies for Oknoplast images
-- This script creates the necessary storage infrastructure

-- Create the storage bucket for product images
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'oknoplast-images',
  'oknoplast-images',
  true,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on storage.objects
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create policy to allow public read access to images
CREATE POLICY "Public read access for oknoplast images" ON storage.objects
FOR SELECT USING (bucket_id = 'oknoplast-images');

-- Create policy to allow authenticated users to upload images
CREATE POLICY "Authenticated users can upload oknoplast images" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'oknoplast-images' 
  AND auth.role() = 'authenticated'
);

-- Create policy to allow authenticated users to update images
CREATE POLICY "Authenticated users can update oknoplast images" ON storage.objects
FOR UPDATE USING (
  bucket_id = 'oknoplast-images' 
  AND auth.role() = 'authenticated'
);

-- Create policy to allow authenticated users to delete images
CREATE POLICY "Authenticated users can delete oknoplast images" ON storage.objects
FOR DELETE USING (
  bucket_id = 'oknoplast-images' 
  AND auth.role() = 'authenticated'
);
