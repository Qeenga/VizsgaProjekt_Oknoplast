-- Restore original Oknoplast products to database
-- This script adds the core window and door products

-- Clear existing products first (optional - remove if you want to keep existing data)
-- DELETE FROM products;

-- Insert Oknoplast window products
INSERT INTO products (name, description, category, price_range, specifications, image_src, link, is_active, sort_order) VALUES
('Koncept-70', 'Kiváló ár-érték arányú 70mm-es profilrendszer. Ideális választás családi házakhoz, energiatakarékos megoldásokkal és modern designnal.', 'ablakok', 'mid', '{"Profilmélység": "70 mm", "Kamraszám": "5 kamrás", "Uw érték": "1,3 W/m²K", "Hangszigetelés": "Rw = 32 dB", "Üvegezés": "Dupla üveg", "Vasalat": "MACO vasalat", "Színek": "Fehér, mahagóni, aranytölgy", "Garancia": "10 év"}', 'https://oknoplast.hu/content/uploads/2025/06/324234.webp', '/termekeink/koncept-70', true, 1),

('Prolux-70', 'Prémium 70mm-es profilrendszer fokozott hőszigetelési tulajdonságokkal. Passzívházakhoz is alkalmas, kiváló minőségű anyagokból.', 'ablakok', 'premium', '{"Profilmélység": "70 mm", "Kamraszám": "6 kamrás", "Uw érték": "1,1 W/m²K", "Hangszigetelés": "Rw = 35 dB", "Üvegezés": "Háromrétegű üveg", "Vasalat": "MACO Prémium", "Színek": "Fehér, színes fóliázás", "Garancia": "15 év"}', 'https://oknoplast.hu/content/uploads/2025/06/324234.webp', '/termekeink/prolux-70', true, 2),

('Winergetic-82', 'A legmagasabb hőszigetelési kategóriájú 82mm-es profilrendszer. Passzívházas szabványnak megfelelő, maximális energiatakarékossággal.', 'ablakok', 'premium', '{"Profilmélység": "82 mm", "Kamraszám": "7 kamrás", "Uw érték": "0,9 W/m²K", "Hangszigetelés": "Rw = 38 dB", "Üvegezés": "Háromrétegű üveg", "Vasalat": "MACO Prémium", "Színek": "Fehér, színes fóliázás", "Garancia": "20 év"}', 'https://oknoplast.hu/content/uploads/2025/06/324234.webp', '/termekeink/winergetic-82', true, 3),

-- Insert door products
('Műanyag Bejárati Ajtók', 'Kiváló hőszigetelési tulajdonságokkal rendelkező műanyag bejárati ajtók. Energiatakarékos megoldás családi házakhoz.', 'ajtok', 'mid', '{"Anyag": "PVC többkamrás profil", "Hőszigetelés": "Ud = 1,2 W/m²K", "Biztonsági": "3 pontos zár", "Hangszigetelés": "Rw = 35 dB", "Garancia": "10 év"}', 'https://oknoplast.hu/content/uploads/2023/05/drzwi-pvc-basic-12-920x721.jpg', '/termekeink/muanyag-bejarati-ajtok', true, 4),

('Műanyag Prémium Ajtók', 'Prémium kategóriás műanyag bejárati ajtók fokozott biztonsági és hőszigetelési tulajdonságokkal.', 'ajtok', 'premium', '{"Anyag": "PVC Prémium profil", "Hőszigetelés": "Ud = 1,0 W/m²K", "Biztonsági": "5 pontos zár RC2", "Hangszigetelés": "Rw = 38 dB", "Garancia": "15 év"}', 'https://oknoplast.hu/content/uploads/2023/05/drzwi-pvc-basic-12-920x721.jpg', '/termekeink/muanyag-premium-ajtok', true, 5),

-- Insert shutter/accessory products
('Külső Redőnyök', 'Alumínium külső redőnyök kiváló árnyékolási és hőszigetelési tulajdonságokkal. Kézi és motoros vezérlés.', 'redonyok', 'mid', '{"Anyag": "Alumínium lamella", "Vezérlés": "Kézi vagy motoros", "Színek": "RAL színskála", "Hőszigetelés": "Javított", "Garancia": "5 év"}', 'https://oknoplast.hu/content/uploads/2023/07/terra-antracyt-5223-920x920.png', '/kapcsolat', true, 6),

('Szúnyoghálók', 'Minőségi szúnyoghálók ablakokhoz és ajtókhoz. Különböző típusokban: fix, tolható, rolós kivitelben.', 'accessories', 'budget', '{"Típusok": "Fix, tolható, rolós", "Anyag": "Üvegszál háló", "Keret": "Alumínium", "Színek": "Fehér, barna", "Garancia": "3 év"}', '/placeholder.svg?height=300&width=400&text=Szúnyogháló', '/kapcsolat', true, 7),

('Ablakpárkányok', 'Belső és külső ablakpárkányok különböző anyagokban. Műanyag, alumínium és természetes kő kivitelben.', 'accessories', 'budget', '{"Típusok": "Belső, külső", "Anyagok": "Műanyag, alumínium, kő", "Színek": "Fehér, színes", "Méretek": "Egyedi", "Garancia": "5 év"}', '/placeholder.svg?height=300&width=400&text=Ablakpárkány', '/kapcsolat', true, 8);
