-- Restoring original products to database
-- Clear existing products first
DELETE FROM products;

-- Insert original Oknoplast products
INSERT INTO products (id, name, description, category, price_range, specifications, image_src, link, is_active, sort_order) VALUES
-- Ablakok
(gen_random_uuid(), 'Koncept-70', 'Költséghatékony 5 kamrás ablakrendszer alapvető hőszigetelési tulajdonságokkal', 'Ablakok', '80.000 - 120.000 Ft', 
 '{"kamraszam": "5 kamrás", "hoszigeteles": "Uw = 1,3 W/m²K", "uvegezés": "4-16-4 mm", "biztonsag": "Alapvető zárrendszer", "szinek": "Fehér, Mahagóni, Arany tölgy"}', 
 '/images/koncept-70.jpg', '/termekeink/koncept-70', true, 1),

(gen_random_uuid(), 'Prolux-70', 'Kiváló ár-érték arányú 6 kamrás ablakrendszer fokozott hőszigetelési tulajdonságokkal', 'Ablakok', '100.000 - 150.000 Ft',
 '{"kamraszam": "6 kamrás", "hoszigeteles": "Uw = 1,1 W/m²K", "uvegezés": "4-16-4 mm argon", "biztonsag": "Fokozott zárrendszer", "szinek": "Fehér, Mahagóni, Arany tölgy, Antracit"}',
 '/images/prolux-70.jpg', '/termekeink/prolux-70', true, 2),

(gen_random_uuid(), 'Winergetic-82', 'Prémium 7 kamrás ablakrendszer kiváló hőszigetelési és hangszigetelési tulajdonságokkal', 'Ablakok', '150.000 - 200.000 Ft',
 '{"kamraszam": "7 kamrás", "hoszigeteles": "Uw = 0,9 W/m²K", "uvegezés": "4-16-4-16-4 mm argon", "biztonsag": "Prémium zárrendszer", "szinek": "Fehér, Mahagóni, Arany tölgy, Antracit, Szürke"}',
 '/images/winergetic-82.jpg', '/termekeink/winergetic-82', true, 3),

-- Ajtók  
(gen_random_uuid(), 'Műanyag Bejárati Ajtók', 'Költséghatékony műanyag bejárati ajtók alapvető biztonsági tulajdonságokkal', 'Ajtók', '120.000 - 180.000 Ft',
 '{"anyag": "PVC", "biztonsag": "3 pontos zárrendszer", "hoszigeteles": "Ud = 1,5 W/m²K", "uvegezés": "Dupla üvegezés", "szinek": "Fehér, Mahagóni, Arany tölgy"}',
 '/images/muanyag-bejarati-ajtok.jpg', '/termekeink/muanyag-bejarati-ajtok', true, 4),

(gen_random_uuid(), 'Műanyag Prémium Ajtók', 'Prémium műanyag bejárati ajtók fokozott biztonsági és hőszigetelési tulajdonságokkal', 'Ajtók', '200.000 - 300.000 Ft',
 '{"anyag": "PVC prémium", "biztonsag": "5 pontos zárrendszer", "hoszigeteles": "Ud = 1,0 W/m²K", "uvegezés": "Háromrétegű üvegezés", "szinek": "Fehér, Mahagóni, Arany tölgy, Antracit"}',
 '/images/muanyag-premium-ajtok.jpg', '/termekeink/muanyag-premium-ajtok', true, 5);
