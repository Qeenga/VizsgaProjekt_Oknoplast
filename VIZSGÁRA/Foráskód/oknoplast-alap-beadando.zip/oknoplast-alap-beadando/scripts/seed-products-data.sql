-- Insert window products
INSERT INTO products (name, category, subcategory, description, image_src, link, specifications, price_range, sort_order) VALUES
('Koncept-70', 'ablakok', 'muanyag', 'Alapvető 5 kamrás profilrendszer kiváló ár-érték aránnyal. Ideális választás családi házakhoz és lakásokhoz, ahol a megbízhatóság és az energiahatékonyság a fő szempont.', '/images/oknoplast-windows.jpg', '/termekeink/koncept-70', '{"kamraszam": "5 kamrás", "Uw": "1,1 W/m²K", "beepitesi_melyseg": "70 mm", "biztonsag": "RC2", "hangszigeteles": "32 dB", "profil": "5 kamrás", "uvegezés": "2 rétegű", "design": "Alapvető, megbízható"}', 'budget', 1),

('Prolux-70', 'ablakok', 'muanyag', 'Prémium 6 kamrás profilrendszer fokozott hőszigetelési tulajdonságokkal. Modern design és kiváló funkcionalitás jellemzi, tökéletes választás igényes otthonokhoz.', '/images/oknoplast-window-anthracite.png', '/termekeink/prolux-70', '{"kamraszam": "6 kamrás", "Uw": "0,9 W/m²K", "beepitesi_melyseg": "70 mm", "biztonsag": "RC2", "hangszigeteles": "35 dB", "profil": "6 kamrás", "uvegezés": "2 rétegű", "design": "Prémium, modern"}', 'mid', 2),

('Winergetic-82', 'ablakok', 'muanyag', 'Az Oknoplast zászlóshajó profilrendszere, amely a legmodernebb technológiákat ötvözi egyetlen profilrendszerben. A 7 kamrás szerkezet és a Termo HS technológia révén kiváló energiahatékonyságot és hosszú élettartamot biztosít minden típusú épülethez.', '/images/okna-dom-parterowy-oknoplast.jpg', '/termekeink/winergetic-82', '{"kamraszam": "7 kamrás", "Uw": "0,6 W/m²K", "beepitesi_melyseg": "82 mm", "biztonsag": "RC2+", "hangszigeteles": "42 dB", "profil": "7 kamrás", "uvegezés": "3 rétegű", "design": "Modern építészet", "technologia": "Termo HS"}', 'premium', 3),

('Pixel-70', 'ablakok', 'muanyag', 'Innovatív design és kiváló teljesítmény kombinációja. A Pixel sorozat modern megjelenést és energiahatékonyságot biztosít, különösen alkalmas kortárs építészeti stílusokhoz.', '/images/oknoplast-group-1.png', '/kapcsolat', '{"kamraszam": "6 kamrás", "Uw": "0,9 W/m²K", "beepitesi_melyseg": "70 mm", "biztonsag": "RC2", "hangszigeteles": "46 dB", "profil": "6 kamrás", "uvegezés": "3 rétegű", "design": "Modern, színes"}', 'mid', 4),

('Prismatic-76', 'ablakok', 'muanyag', 'Nagyobb beépítési mélységgel rendelkező profilrendszer, amely kiváló hő- és hangszigetelést biztosít. Ideális választás extrém időjárási viszonyoknak kitett épületekhez.', 'https://oknoplast.hu/content/uploads/2023/03/prismatic-woodec-turner-oak-malt-1-920x920.png', '/kapcsolat', '{"kamraszam": "6 kamrás", "Uw": "0,8 W/m²K", "beepitesi_melyseg": "76 mm", "biztonsag": "RC2", "hangszigeteles": "42 dB", "profil": "5 kamrás", "uvegezés": "2 rétegű", "design": "Egyedi dizájn"}', 'mid', 5),

-- Insert door products
('Műanyag bejárati ajtók', 'ajtok', 'bejarati', 'Kiváló hőszigetelési tulajdonságokkal rendelkező műanyag bejárati ajtók. Energiatakarékos megoldás családi házakhoz, karbantartásmentes felülettel és hosszú élettartammal.', '/images/oknoplast-hero.jpg', '/termekeink/muanyag-bejarati-ajtok', '{"anyag": "PVC", "hoszigeteles": "Kiváló", "biztonsag": "3 pontos zár", "design": "Modern", "vastagság": "70mm", "szinvalasztek": "Széles", "Ud": "1,2 W/m²K", "hangszigeteles": "35 dB"}', 'budget', 1),

('Műanyag Prémium Ajtók', 'ajtok', 'bejarati', 'Prémium kategóriás műanyag bejárati ajtók fokozott biztonsági és hőszigetelési tulajdonságokkal. Modern design és kiváló funkcionalitás jellemzi.', '/images/hero-background.jpg', '/termekeink/muanyag-premium-ajtok', '{"anyag": "PVC Prémium", "hoszigeteles": "Prémium", "biztonsag": "5 pontos zár", "design": "Elegáns", "vastagság": "82mm", "szinvalasztek": "Prémium", "Ud": "1,0 W/m²K", "hangszigeteles": "38 dB"}', 'premium', 2),

('Alumínium Bejárati ajtók', 'ajtok', 'bejarati', 'Modern alumínium bejárati ajtók tartós szerkezettel és elegáns megjelenéssel. Ideális választás kortárs építészeti stílusokhoz és irodaépületekhez.', '/images/oknoplast-windows.jpg', '/kapcsolat', '{"anyag": "Alumínium", "hoszigeteles": "Jó", "biztonsag": "3 pontos zár", "design": "Modern", "vastagság": "75mm", "szinvalasztek": "Korlátozott"}', 'mid', 3),

('Acél Bejárati ajtók', 'ajtok', 'bejarati', 'Maximális biztonságot nyújtó acél bejárati ajtók fém vagy fa tokkal. Kiváló betörésvédelem és hosszú élettartam jellemzi, különböző design opciókkal.', '/images/oknoplast-window-anthracite.png', '/kapcsolat', '{"anyag": "Acél", "hoszigeteles": "Közepes", "biztonsag": "7 pontos zár", "design": "Biztonságos", "vastagság": "80mm", "szinvalasztek": "Alapvető"}', 'premium', 4),

-- Insert shutter/accessory products
('Alu Redőny', 'redonyok', 'kulso', 'Különböző típusú redőnyök a tökéletes árnyékolásért.', '/images/jakie-okna-do-domu-parterowego.jpg', '/kapcsolat', '{"anyag": "Alumínium", "szigeteles": "Közepes", "motoros": "Igen", "szinvalasztek": "Széles", "lamella": "55mm", "vezerlés": "Távirányító"}', 'mid', 1),

('Műanyag Redőny', 'redonyok', 'kulso', 'Praktikus műanyag redőnyök megfizethető áron.', '/images/oknoplast-hero.jpg', '/kapcsolat', '{"anyag": "PVC", "szigeteles": "Jó", "motoros": "Nem", "szinvalasztek": "Korlátozott", "lamella": "50mm", "vezerlés": "Kézi"}', 'budget', 2),

('Prémium Redőny', 'redonyok', 'kulso', 'Prémium redőnyök a legmagasabb minőségi követelményekkel.', '/images/hero-background.jpg', '/kapcsolat', '{"anyag": "Alumínium Prémium", "szigeteles": "Kiváló", "motoros": "Igen", "szinvalasztek": "Prémium", "lamella": "60mm", "vezerlés": "Smart Home"}', 'premium', 3),

('Szúnyoghálók', 'accessories', 'kiegeszito', 'Praktikus szúnyoghálók ablakokra és ajtókra.', '/images/oknoplast-hero.jpg', '/kapcsolat', '{"anyag": "Finom szövés", "tisztitas": "Könnyen tisztítható", "tartossag": "Tartós anyag", "meretek": "Egyedi méretek"}', 'budget', 1),

('Párkányok', 'accessories', 'kiegeszito', 'Kül- és beltéri párkányok széles választékban.', '/images/hero-background.jpg', '/kapcsolat', '{"anyagok": "Különböző anyagok", "idojarasallo": "Időjárásálló", "meretek": "Egyedi méretek", "szereles": "Könnyű szerelés"}', 'budget', 2);
