import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Clock, User, Calendar, Shield, Thermometer, Wind, Sun } from "lucide-react"

export default function ZsaluziaVagyKulsoRedony() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link href="/blog" className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a bloghoz
        </Link>

        <div className="mb-6">
          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">ÁRNYÉKOLÁS</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Zsaluzia vagy külső redőny?</h1>

        <div className="flex items-center space-x-6 text-gray-600 mb-8">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            <span>2025. június 16.</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-2" />
            <span>3 perc olvasás</span>
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            <span>Oknoplast Szakértő</span>
          </div>
        </div>
      </div>

      <div className="relative h-96 mb-8 rounded-lg overflow-hidden">
        <Image
          src="/placeholder.svg?height=400&width=800&text=Zsaluzia+vs+Külső+Redőny"
          alt="Zsaluzia vagy külső redőny összehasonlítás"
          fill
          className="object-cover"
        />
      </div>

      <div className="max-w-4xl mx-auto prose prose-lg">
        <p className="text-xl text-gray-700 mb-6">
          Azon gondolkodik, hogy melyiket válassza – zsaluzia vagy külső redőny? Ez a dilemma a legtöbb házat építő vagy
          korszerűsítő embernél felmerül. Nem véletlenül – mindkét megoldásnak megvannak az előnyei, és jelenleg
          rendkívül népszerűek. Ismerje meg a zsaluzia és a redőny pozitívumait, hogy eldönthesse, melyik kültéri
          árnyékolótípus felel meg jobban az Ön igényeinek.
        </p>

        <h2 className="text-2xl font-bold text-primary mb-4">Zsaluzia vagy redőny – a megjelenés számít</h2>
        <p className="mb-6">
          Ha Ön számára az ablakokkal integrált árnyékoló kiválasztásának legfontosabb szempontja a megjelenés, akkor
          valószínűleg a zsaluzia mellett dönt. A külső redőnyökhöz képest eltérő szerkezettel rendelkeznek, és
          funkcionális szerepük mellett díszítőelemként is szolgálnak. A zsaluzia optikailag könnyebb, mivel dönthető
          alumínium lamellákból áll. A redőnyökhöz képest nem tömör árnyékolót, hanem minimalista szerkezetet kínál,
          amely egész nap esztétikus kiegészítője az épület homlokzatának. Az OKNOPLAST zsaluzia típusai ideálisak a
          modern stílusú, nagy üvegfelületekkel és üveg homlokzatokkal rendelkező épületekhez.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Shield className="h-5 w-5 text-primary mr-2" />
              Biztonság
            </h3>
            <p className="text-sm">
              Fontos Önnek a betörés elleni védelem és a családtagok nyugodt alvása? Válassza a magas szintű biztonságot
              nyújtó külső redőnyöket, például az OKNOPLAST kínálatából. Ezek általában nagyobb védelmet nyújtanak, mint
              a zsaluzia, köszönhetően a masszív szerkezetnek, a zárt páncélnak, valamint az automatikus reteszeknek és
              blokkoló tartóelemeknek. A leeresztett és zárt redőnypáncél erőszakkal történő felemelése lényegesen
              nehezebb, mint a zsaluziáé.
            </p>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Thermometer className="h-5 w-5 text-primary mr-2" />
              Hőszigetelés
            </h3>
            <p className="text-sm">
              Fontos Önnek a téli hőveszteségek csökkentése és a nyári hőség elleni védelem? Jó megoldás lehet a
              szigetelt páncéllal és tokozással ellátott, kiváló minőségű külső redőny, például az OKNOPLAST Sol
              Evolution modellje. A helyesen felszerelt, gondosan használt redőnyök a hideg hónapokban észrevehető
              energiamegtakarítást biztosítanak.
            </p>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Wind className="h-5 w-5 text-primary mr-2" />
              Szellőzés
            </h3>
            <p className="text-sm">
              Fontos szempont Önnek, hogy az árnyékolás mellett biztosított legyen a természetes szellőzés is? Ebben az
              esetben érdemesebb zsaluzia mellett dönteni. A zsaluzia nemcsak nyitott állapotban biztosít légmozgást,
              hanem részlegesen vagy szinte teljesen zárt lamellákkal is.
            </p>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Sun className="h-5 w-5 text-primary mr-2" />
              Napfény elleni védelem
            </h3>
            <p className="text-sm">
              Olyan árnyékolót keres, amely biztosítja a kellemes beltéri klímát a folyamatos napsütésnek kitett
              helyiségekben? A legjobb megoldás a zsaluzia. A redőnyökkel ellentétben a zsaluziák nemcsak fel- és
              leengedhetők, hanem a lamellák dőlésszöge is állítható. Ezáltal a bejutó fény mennyisége pontosan
              szabályozható.
            </p>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Szerelési mód</h2>
        <p className="mb-6">
          Az OKNOPLAST zsaluziái és külső redőnyei egyaránt az ablaknyílásba kerülnek beépítésre úgy, hogy egyik elemük
          sem lóg ki a fal síkjából. Ennek köszönhetően az árnyékolók zárt vagy felhúzott állapotban esztétikus és
          rendezett megjelenést nyújtanak. Kivételt képez az OKNOPLAST Terra redőnymodell, amely a fal külső síkjára
          szerelve látható tokkal és vezetősínekkel rendelkezik.
        </p>

        <div className="bg-primary/10 p-6 rounded-lg mb-8">
          <h3 className="text-xl font-bold text-primary mb-3">🏆 OKNOPLAST árnyékolási megoldások</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-bold mb-2">Zsaluzia előnyei</h4>
              <ul className="space-y-1 text-sm">
                <li>✓ Modern, minimalista megjelenés</li>
                <li>✓ Állítható lamellák</li>
                <li>✓ Természetes szellőzés</li>
                <li>✓ Pontos fényszabályozás</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Külső redőny előnyei</h4>
              <ul className="space-y-1 text-sm">
                <li>✓ Maximális biztonság</li>
                <li>✓ Kiváló hőszigetelés</li>
                <li>✓ Teljes sötétítés</li>
                <li>✓ Energiamegtakarítás</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-accent/10 p-6 rounded-lg mb-8">
          <h3 className="text-xl font-bold text-primary mb-3">💡 Szakértői tanács</h3>
          <p>
            Bármelyik megoldást is választja, érdemes olyan szerelőcsapatot megbízni, amely ismeri a kiválasztott
            rendszert. Az OKNOPLAST külső redőnyeihez és zsaluziáihoz partnereink ajánlásait értékesítési pontjainkon
            szerezheti be.
          </p>
        </div>

        <div className="text-center mt-12">
          <Link href="/kapcsolat" className="btn-primary mr-4">
            Árnyékolási tanácsadás
          </Link>
          <Link href="/termekeink" className="btn-secondary">
            Termékek megtekintése
          </Link>
        </div>
      </div>
    </div>
  )
}
