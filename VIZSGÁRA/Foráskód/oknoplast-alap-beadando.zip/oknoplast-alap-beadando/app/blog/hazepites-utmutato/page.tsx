import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import ContactCTA from "@/components/contact-cta"
import { Calendar, User, Clock, ArrowLeft, Share2, BookOpen, CheckCircle } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function HazepitesUtmutatoPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Link href="/blog" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vissza a bloghoz
          </Link>
        </div>
      </div>

      {/* Article */}
      <article className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Article Header */}
          <header className="mb-8">
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="secondary">Útmutató</Badge>
              <Badge variant="outline">Házépítés</Badge>
              <Badge variant="outline">Tippek</Badge>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Házépítés útmutató: Mire figyeljen ablak- és ajtóválasztáskor?
            </h1>

            <div className="flex flex-wrap items-center gap-6 text-gray-600 mb-6">
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                2024. március 15.
              </div>
              <div className="flex items-center">
                <User className="w-4 h-4 mr-2" />
                Nagy Péter
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-2" />8 perc olvasás
              </div>
            </div>

            <div className="relative aspect-video mb-8">
              <Image
                src="/images/okna-dom-parterowy-oknoplast.jpg"
                alt="Modern ház Oknoplast ablakokkal"
                fill
                className="object-cover rounded-lg"
              />
            </div>
          </header>

          {/* Article Content */}
          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-gray-600 mb-8">
              A házépítés során az ablakok és ajtók kiválasztása kulcsfontosságú döntés, amely hosszú távon befolyásolja
              otthona komfortját, energiahatékonyságát és értékét. Ebben az útmutatóban összegyűjtöttük a legfontosabb
              szempontokat, amelyekre érdemes figyelni.
            </p>

            <h2 className="text-2xl font-bold text-primary mb-4">1. Energiahatékonyság és hőszigetelés</h2>
            <p className="mb-6">
              Az energiahatékony ablakok és ajtók jelentős mértékben csökkenthetik fűtési költségeit. A modern műanyag
              nyílászárók kiváló hőszigetelési tulajdonságokkal rendelkeznek, amelyek télen megtartják a meleget, nyáron
              pedig távol tartják a hőséget.
            </p>

            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2 text-green-500" />
                  Fontos hőszigetelési értékek
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li>
                    <strong>Uw érték:</strong> Az ablak teljes hőszigetelési értéke (minél alacsonyabb, annál jobb)
                  </li>
                  <li>
                    <strong>Ug érték:</strong> Az üveg hőszigetelési értéke
                  </li>
                  <li>
                    <strong>Uf érték:</strong> A keret hőszigetelési értéke
                  </li>
                </ul>
              </CardContent>
            </Card>

            <h2 className="text-2xl font-bold text-primary mb-4">2. Megfelelő profilrendszer választása</h2>
            <p className="mb-6">
              A profilrendszer meghatározza az ablak stabilitását, hőszigetelését és tartósságát. Az Oknoplast különböző
              profilmélységeket kínál, 70 mm-től 82 mm-ig, hogy minden igényt kielégítsen.
            </p>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">70 mm profil</CardTitle>
                  <CardDescription>Alapvető megoldás</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm space-y-1">
                    <li>• 5 kamrás szerkezet</li>
                    <li>• Jó ár-érték arány</li>
                    <li>• Uw = 1,3 W/m²K</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">76 mm profil</CardTitle>
                  <CardDescription>Középkategória</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm space-y-1">
                    <li>• 6 kamrás szerkezet</li>
                    <li>• Jobb hőszigetelés</li>
                    <li>• Uw = 1,1 W/m²K</li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">82 mm profil</CardTitle>
                  <CardDescription>Prémium kategória</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm space-y-1">
                    <li>• 6 kamrás szerkezet</li>
                    <li>• Passzívház szabvány</li>
                    <li>• Uw = 0,9 W/m²K</li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <h2 className="text-2xl font-bold text-primary mb-4">3. Üvegezés típusok</h2>
            <p className="mb-6">
              Az üvegezés típusa jelentős mértékben befolyásolja az ablak teljesítményét. A modern háromrétegű üvegezés
              kiváló hő- és hangszigetelést biztosít.
            </p>

            <h2 className="text-2xl font-bold text-primary mb-4">4. Biztonság és védelem</h2>
            <p className="mb-6">
              A biztonság szempontjából fontos a megfelelő zárrendszer és biztonsági üvegezés választása. Az RC2
              biztonsági osztályú nyílászárók alapvető védelmet nyújtanak a betörések ellen.
            </p>

            <h2 className="text-2xl font-bold text-primary mb-4">5. Tervezési és esztétikai szempontok</h2>
            <p className="mb-6">
              Az ablakok és ajtók stílusa illeszkedjen a ház építészeti karakteréhez. A színválasztásnál vegye
              figyelembe a homlokzat színét és a környezet jellegét.
            </p>

            <Card className="bg-blue-50 border-blue-200 mb-8">
              <CardHeader>
                <CardTitle className="flex items-center text-primary">
                  <BookOpen className="w-5 h-5 mr-2" />
                  Szakértői tanács
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  "A házépítés során érdemes már a tervezési fázisban konzultálni ablak-szakértővel. A helyes méretezés
                  és elhelyezés jelentős energiamegtakarítást eredményezhet." - Nagy Péter, Oknoplast Debrecen
                </p>
              </CardContent>
            </Card>

            <h2 className="text-2xl font-bold text-primary mb-4">Összefoglalás</h2>
            <p className="mb-6">
              A megfelelő ablakok és ajtók kiválasztása komplex feladat, amely szakértői segítséget igényel. Az
              Oknoplast Debrecen tapasztalt csapata minden lépésben támogatja Önt, a tervezéstől a beépítésig.
            </p>

            <div className="bg-primary text-white p-6 rounded-lg text-center">
              <h3 className="text-xl font-bold mb-4">Kérjen személyre szabott tanácsadást!</h3>
              <p className="mb-4">
                Szakértő csapatunk ingyenes helyszíni felméréssel segít megtalálni a tökéletes megoldást.
              </p>
              <Button variant="secondary" size="lg" asChild>
                <Link href="/kapcsolat">Ingyenes konzultáció</Link>
              </Button>
            </div>
          </div>

          {/* Share */}
          <div className="mt-8 pt-8 border-t">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Share2 className="w-5 h-5 mr-2 text-gray-600" />
                <span className="text-gray-600">Ossza meg:</span>
              </div>
              <div className="flex space-x-4">
                <Button variant="outline" size="sm">
                  Facebook
                </Button>
                <Button variant="outline" size="sm">
                  LinkedIn
                </Button>
                <Button variant="outline" size="sm">
                  Email
                </Button>
              </div>
            </div>
          </div>
        </div>
      </article>

      <ContactCTA />
    </div>
  )
}
