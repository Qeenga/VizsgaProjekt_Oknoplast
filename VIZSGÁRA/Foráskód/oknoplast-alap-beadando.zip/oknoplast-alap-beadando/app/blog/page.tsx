import Image from "next/image"
import Link from "next/link"
import { Clock, User } from "lucide-react"

export default function Blog() {
  return (
    <div className="container-custom">
      <div className="text-center mb-12">
        <h1 className="section-title inline-block">Oknoplast szakértői tudás</h1>
        <p className="max-w-2xl mx-auto mt-4 text-base md:text-lg">
          30+ év lengyel ablakgyártási tapasztalat és európai innovációk. Fedezze fel az Oknoplast prémium minőségű
          nyílászáróinak világát szakértői útmutatóinkkal.
        </p>
        <div className="mt-4 text-sm text-gray-600 flex flex-col sm:flex-row items-center justify-center gap-2">
          <span className="bg-primary/10 px-3 py-1 rounded-full">🇵🇱 Lengyel prémium minőség</span>
          <span className="bg-accent/10 px-3 py-1 rounded-full">🏆 Európa vezető ablakgyártója</span>
        </div>
      </div>

      <div className="blog-grid">
        <BlogCard
          category="5 CIKKEK"
          title="Útmutató – Az ablakvásárlás folyamata"
          description="Hogyan válasszunk nyílászárókat? Mire érdemes figyelni az ablakok kiválasztásakor? Komplett útmutató az ablakgyártó kiválasztásától a beépítésig."
          imageSrc="/images/oknoplast-windows.jpg"
          readTime="12 perc"
          slug="ablakvasarlas-folyamata"
        />

        <BlogCard
          category="5 CIKKEK"
          title="Útmutató – Ablakcsere"
          description="Ablakcsere régi házban és társasházban - lépésről lépésre. Mire kell figyelni, hogyan válasszunk megfelelő fürdőszobai ablakot és külső redőnyöket."
          imageSrc="/images/oknoplast-group-1.png"
          readTime="10 perc"
          slug="ablakcsere-utmutato"
        />

        <BlogCard
          category="ENERGIATAKARÉKOSSÁG"
          title="Mely ablakok a legenergiatakarékosabbak?"
          description="Az energiatakarékos ablakok kiválasztása kulcsfontosságú a modern otthonokban. Megtudhatja, mely ablakok nyújtják a legjobb energiahatékonyságot és hogyan választhatja ki a megfelelőt."
          imageSrc="/images/okna-winergetic-oknoplast-bedroom.jpg"
          readTime="8 perc"
          slug="mely-ablakok-a-legenergiatakarekosabbak"
        />

        <BlogCard
          category="1 CIKK"
          title="Útmutató – Korszerű technológiák"
          description="Fedezze fel a legújabb ablak- és ajtótechnológiákat! Intelligens üvegezés, automatizált rendszerek és innovatív megoldások a modern otthonokhoz."
          imageSrc="/images/oknoplast-windows.jpg"
          readTime="6 perc"
          slug="korszeru-technologiak"
        />

        <BlogCard
          category="ÁRNYÉKOLÁS"
          title="Zsaluzia vagy külső redőny?"
          description="Azon gondolkodik, hogy melyiket válassza – zsaluzia vagy külső redőny? Ismerje meg mindkét megoldás előnyeit és hátrányait, hogy a legjobb döntést hozhassa meg."
          imageSrc="/placeholder.svg?height=300&width=400&text=Zsaluzia+vs+Redőny"
          readTime="3 perc"
          slug="zsaluzia-vagy-kulso-redony"
        />
      </div>

      <div className="text-center mt-12">
        <Link href="/kapcsolat" className="btn-primary">
          További kérdések? Vegye fel velünk a kapcsolatot!
        </Link>
      </div>
    </div>
  )
}

function BlogCard({
  category,
  title,
  description,
  imageSrc,
  readTime,
  slug,
}: {
  category: string
  title: string
  description: string
  imageSrc: string
  readTime: string
  slug: string
}) {
  return (
    <div className="blog-card hover:shadow-xl hover:-translate-y-1">
      <div className="relative h-48 md:h-64 group">
        <Image
          src={imageSrc || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-all duration-300"></div>
        <div className="absolute top-4 left-4">
          <span className="bg-primary text-white px-2 md:px-3 py-1 rounded-full text-xs md:text-sm font-semibold">
            {category}
          </span>
        </div>
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-12 h-12 md:w-16 md:h-16 bg-white/90 rounded-full flex items-center justify-center">
            <svg className="w-4 h-4 md:w-6 md:h-6 text-primary" fill="currentColor" viewBox="0 0 20 20">
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"
                clipRule="evenodd"
              />
            </svg>
          </div>
        </div>
      </div>

      <div className="p-4 md:p-6">
        <h3 className="text-lg md:text-xl font-bold text-primary mb-3 line-clamp-2">{title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-3 text-sm md:text-base">{description}</p>

        <div className="flex items-center justify-between text-xs md:text-sm text-gray-500 mb-4">
          <div className="flex items-center">
            <Clock className="h-3 w-3 md:h-4 md:w-4 mr-1" />
            <span>{readTime} olvasás</span>
          </div>
          <div className="flex items-center">
            <User className="h-3 w-3 md:h-4 md:w-4 mr-1" />
            <span>Szakértő</span>
          </div>
        </div>

        <Link
          href={`/blog/${slug}`}
          className="inline-flex items-center text-primary font-semibold hover:text-accent transition-colors text-sm md:text-base"
        >
          Tovább olvasom
          <svg className="w-3 h-3 md:w-4 md:h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </Link>
      </div>
    </div>
  )
}
