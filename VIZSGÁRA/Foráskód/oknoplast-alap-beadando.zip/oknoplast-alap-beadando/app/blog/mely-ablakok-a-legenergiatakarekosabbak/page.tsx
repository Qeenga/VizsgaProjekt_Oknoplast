import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import ContactCTA from "@/components/contact-cta"
import { Calendar, User, Clock, ArrowLeft, Share2, Thermometer, Zap, TrendingDown } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function EnergiatakarekosAblakokPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Link href="/blog" className="inline-flex items-center text-primary hover:text-primary/80 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Vissza a bloghoz
          </Link>
        </div>
      </div>

      {/* Article */}
      <article className="py-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Article Header */}
          <header className="mb-8">
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="secondary">Energiatakarékosság</Badge>
              <Badge variant="outline">Ablakok</Badge>
              <Badge variant="outline">Környezetvédelem</Badge>
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Mely ablakok a legenergiatakarékosabbak? Útmutató a hatékony választáshoz
            </h1>

            <div className="flex flex-wrap items-center gap-6 text-gray-600 mb-6">
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                2024. március 10.
              </div>
              <div className="flex items-center">
                <User className="w-4 h-4 mr-2" />
                Kovács Anna
              </div>
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-2" />6 perc olvasás
              </div>
            </div>

            <div className="relative aspect-video mb-8">
              <Image
                src="/images/okna-winergetic-oknoplast-bedroom.jpg"
                alt="Energiatakarékos Winergetic ablakok hálószobában"
                fill
                className="object-cover rounded-lg"
              />
            </div>
          </header>

          {/* Article Content */}
          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-gray-600 mb-8">
              Az energiatakarékos ablakok nemcsak a környezetet védik, hanem jelentős megtakarítást is eredményezhetnek
              a fűtési költségekben. De mely ablakok tekinthetők valóban energiatakarékosnak, és mire érdemes figyelni a
              választáskor?
            </p>

            <h2 className="text-2xl font-bold text-primary mb-4">Mi tesz egy ablakot energiatakarékossá?</h2>
            <p className="mb-6">
              Az energiatakarékosság több tényező együttes hatásának eredménye. A legfontosabb paraméterek:
            </p>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <Thermometer className="w-8 h-8 text-blue-600 mb-2" />
                  <CardTitle className="text-lg">Hőszigetelés (Uw érték)</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Minél alacsonyabb az Uw érték, annál jobb a hőszigetelés. Passzívházakhoz 0,8 W/m²K alatti érték
                    szükséges.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-green-50 border-green-200">
                <CardHeader>
                  <Zap className="w-8 h-8 text-green-600 mb-2" />
                  <CardTitle className="text-lg">Napenergia hasznosítás</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    A megfelelő g-érték biztosítja, hogy télen a napsugárzás fűtse az otthont, nyáron pedig ne
                    melegedjen túl.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-orange-50 border-orange-200">
                <CardHeader>
                  <TrendingDown className="w-8 h-8 text-orange-600 mb-2" />
                  <CardTitle className="text-lg">Légáteresztés</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    Az alacsony légáteresztési érték (a-érték) megakadályozza a hőveszteséget és a huzatot.
                  </p>
                </CardContent>
              </Card>
            </div>

            <h2 className="text-2xl font-bold text-primary mb-4">Az Oknoplast energiatakarékos ablakrendszerei</h2>

            <h3 className="text-xl font-semibold text-primary mb-3">
              WINERGETIC 82 - A legenergiatakarékosabb választás
            </h3>
            <p className="mb-4">A WINERGETIC 82 rendszer passzívház szabványnak megfelelő teljesítményt nyújt:</p>
            <ul className="list-disc list-inside mb-6 space-y-2">
              <li>82 mm profilmélység 6 kamrával</li>
              <li>Uw = 0,9 W/m²K hőszigetelési érték</li>
              <li>Háromrétegű energiatakarékos üvegezés</li>
              <li>Akár 40% energiamegtakarítás a hagyományos ablakokhoz képest</li>
            </ul>

            <h3 className="text-xl font-semibold text-primary mb-3">PROLUX 70 - Kiváló ár-érték arány</h3>
            <p className="mb-4">A PROLUX 70 rendszer középkategóriás energiatakarékosságot biztosít:</p>
            <ul className="list-disc list-inside mb-6 space-y-2">
              <li>70 mm profilmélység 5 kamrával</li>
              <li>Uw = 1,1 W/m²K hőszigetelési érték</li>
              <li>Dupla üvegezés argon gáztöltéssel</li>
              <li>Akár 25% energiamegtakarítás</li>
            </ul>

            <Card className="bg-green-50 border-green-200 mb-8">
              <CardHeader>
                <CardTitle className="flex items-center text-green-800">
                  <TrendingDown className="w-5 h-5 mr-2" />
                  Éves megtakarítás kalkulátor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-green-700 mb-4">Egy átlagos családi háznál (150 m²) a WINERGETIC 82 ablakokkal:</p>
                <ul className="space-y-2 text-green-700">
                  <li>• Éves fűtési költség megtakarítás: 150-200.000 Ft</li>
                  <li>• CO₂ kibocsátás csökkentés: 1,2 tonna/év</li>
                  <li>• Megtérülési idő: 8-10 év</li>
                </ul>
              </CardContent>
            </Card>

            <h2 className="text-2xl font-bold text-primary mb-4">Mire figyeljen a választáskor?</h2>

            <h3 className="text-xl font-semibold text-primary mb-3">1. Tájolás és napfény</h3>
            <p className="mb-4">
              Déli tájolású ablakoknál alacsonyabb g-értékű üvegezést válasszon a túlmelegedés elkerülése érdekében.
              Északi oldalon pedig magasabb g-értékű üvegezés segít a napenergia hasznosításában.
            </p>

            <h3 className="text-xl font-semibold text-primary mb-3">2. Épület energetikai jellemzői</h3>
            <p className="mb-4">
              Új építésű, jól szigetelt házakhoz érdemes a legenergiatakarékosabb ablakokat választani. Felújításnál is
              jelentős javulást érhet el a régi ablakok cseréjével.
            </p>

            <h3 className="text-xl font-semibold text-primary mb-3">3. Támogatási lehetőségek</h3>
            <p className="mb-6">
              Számos állami és EU-s támogatás érhető el energiatakarékos ablakok beépítéséhez. Érdeklődjön a jelenleg
              elérhető pályázatokról!
            </p>

            <div className="bg-primary text-white p-6 rounded-lg text-center">
              <h3 className="text-xl font-bold mb-4">Számítsa ki a megtakarítást!</h3>
              <p className="mb-4">
                Kérjen személyre szabott energetikai számítást és ajánlatot energiatakarékos ablakainkra.
              </p>
              <Button variant="secondary" size="lg" asChild>
                <Link href="/kapcsolat">Ingyenes számítás</Link>
              </Button>
            </div>
          </div>

          {/* Share */}
          <div className="mt-8 pt-8 border-t">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Share2 className="w-5 h-5 mr-2 text-gray-600" />
                <span className="text-gray-600">Ossza meg:</span>
              </div>
              <div className="flex space-x-4">
                <Button variant="outline" size="sm">
                  Facebook
                </Button>
                <Button variant="outline" size="sm">
                  LinkedIn
                </Button>
                <Button variant="outline" size="sm">
                  Email
                </Button>
              </div>
            </div>
          </div>
        </div>
      </article>

      <ContactCTA />
    </div>
  )
}
