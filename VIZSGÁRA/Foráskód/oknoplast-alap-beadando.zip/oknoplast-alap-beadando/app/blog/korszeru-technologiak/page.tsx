import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Clock, User, Calendar, Smartphone, Zap, Eye, Thermometer } from "lucide-react"

export default function KorszeruTechnologiak() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link href="/blog" className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a bloghoz
        </Link>

        <div className="mb-6">
          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">TECHNOLÓGIA</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Útmutató – Korszerű technológiák</h1>

        <div className="flex items-center space-x-6 text-gray-600 mb-8">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            <span>2024. február 1.</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-2" />
            <span>6 perc olvasás</span>
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            <span>Oknoplast Szakértő</span>
          </div>
        </div>
      </div>

      <div className="relative h-96 mb-8 rounded-lg overflow-hidden">
        <Image
          src="/images/oknoplast-windows.jpg"
          alt="Korszerű ablak technológiák - Oknoplast innovációk"
          fill
          className="object-cover"
        />
      </div>

      <div className="max-w-4xl mx-auto prose prose-lg">
        <p className="text-xl text-gray-700 mb-6">
          Az Oknoplast, mint Európa egyik vezető lengyel ablakgyártója, folyamatosan fejleszti technológiáit. A krakkói
          kutatás-fejlesztési központban dolgozó mérnökök olyan innovációkat hoznak létre, amelyek forradalmasítják a
          nyílászáró ipart. Fedezze fel a legújabb Oknoplast technológiákat!
        </p>

        <h2 className="text-2xl font-bold text-primary mb-4">Intelligens üvegezési technológiák</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="flex items-center mb-3">
              <Eye className="h-6 w-6 text-primary mr-2" />
              <h3 className="font-bold text-lg">Elektrokromatikus üveg</h3>
            </div>
            <p className="text-sm mb-3">
              Elektromos árammal szabályozható átlátszóság. Gombnyomásra válik átlátszóból mattá.
            </p>
            <ul className="text-sm space-y-1">
              <li>• Magánszféra védelem</li>
              <li>• Energiamegtakarítás</li>
              <li>• Okostelefon vezérlés</li>
            </ul>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="flex items-center mb-3">
              <Thermometer className="h-6 w-6 text-primary mr-2" />
              <h3 className="font-bold text-lg">Termokromatikus üveg</h3>
            </div>
            <p className="text-sm mb-3">Hőmérséklet-érzékeny üveg, amely automatikusan sötétedik melegben.</p>
            <ul className="text-sm space-y-1">
              <li>• Automatikus árnyékolás</li>
              <li>• UV védelem</li>
              <li>• Karbantartásmentes</li>
            </ul>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Smart Home integráció</h2>

        <div className="bg-accent/10 p-6 rounded-lg mb-6">
          <div className="flex items-start mb-4">
            <Smartphone className="h-6 w-6 text-primary mr-3 mt-1" />
            <div>
              <h3 className="font-bold text-lg mb-2">Okos ablak és ajtó rendszerek</h3>
              <p className="text-gray-700">
                A modern nyílászárók integrálhatók az okos otthon rendszerekbe, lehetővé téve a távoli vezérlést és
                automatizálást.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-bold mb-2">Vezérlési lehetőségek</h4>
              <ul className="space-y-1 text-sm">
                <li>• Okostelefon alkalmazás</li>
                <li>• Hangvezérlés (Alexa, Google)</li>
                <li>• Időzített működés</li>
                <li>• Érzékelő alapú automatika</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Monitorozás</h4>
              <ul className="space-y-1 text-sm">
                <li>• Nyitás/zárás állapot</li>
                <li>• Hőmérséklet mérés</li>
                <li>• Levegőminőség</li>
                <li>• Biztonsági riasztás</li>
              </ul>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Energiahatékony megoldások</h2>

        <div className="space-y-6 mb-8">
          <div className="border-l-4 border-primary pl-6">
            <h3 className="font-bold text-lg mb-2">Tripla üvegezés argon töltéssel</h3>
            <p className="text-gray-700 mb-2">
              A legmodernebb hőszigetelési technológia, amely akár 0,5 W/m²K U-értéket is elérhet.
            </p>
            <ul className="text-sm space-y-1">
              <li>• 50% jobb hőszigetelés dupla üveghez képest</li>
              <li>• Jelentős energiamegtakarítás</li>
              <li>• Kondenzációmentes felület</li>
            </ul>
          </div>

          <div className="border-l-4 border-accent pl-6">
            <h3 className="font-bold text-lg mb-2">Vakuumos üvegezés</h3>
            <p className="text-gray-700 mb-2">
              A jövő technológiája: két üvegtábla között vákuum biztosítja a tökéletes hőszigetelést.
            </p>
            <ul className="text-sm space-y-1">
              <li>• Rendkívül vékony szerkezet</li>
              <li>• Kiváló hőszigetelés</li>
              <li>• Hosszú élettartam</li>
            </ul>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Automatizált rendszerek</h2>

        <div className="bg-primary/10 p-6 rounded-lg mb-6">
          <div className="flex items-start mb-4">
            <Zap className="h-6 w-6 text-primary mr-3 mt-1" />
            <div>
              <h3 className="font-bold text-lg mb-2">Motorikus meghajtások</h3>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <h4 className="font-bold mb-2">Redőnyök</h4>
              <ul className="text-sm space-y-1">
                <li>• Időzített működés</li>
                <li>• Napkövető rendszer</li>
                <li>• Szélsebesség érzékelő</li>
              </ul>
            </div>
            <div className="text-center">
              <h4 className="font-bold mb-2">Ablakok</h4>
              <ul className="text-sm space-y-1">
                <li>• Automatikus szellőzés</li>
                <li>• Esőérzékelő</li>
                <li>• CO₂ szint alapú nyitás</li>
              </ul>
            </div>
            <div className="text-center">
              <h4 className="font-bold mb-2">Ajtók</h4>
              <ul className="text-sm space-y-1">
                <li>• Ujjlenyomat olvasó</li>
                <li>• Arcfelismerés</li>
                <li>• Kódos belépés</li>
              </ul>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Biztonsági innovációk</h2>
        <div className="bg-gray-50 p-6 rounded-lg mb-6">
          <h3 className="font-bold text-lg mb-3">Legújabb biztonsági technológiák</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="space-y-2">
              <li>
                <strong>Többpontos zárrendszer:</strong> 5-7 zárási pont
              </li>
              <li>
                <strong>Biztonsági üveg:</strong> P4A-P8B osztályú
              </li>
              <li>
                <strong>Riasztórendszer integráció:</strong> Nyitás érzékelés
              </li>
            </ul>
            <ul className="space-y-2">
              <li>
                <strong>Rejtett zsanérok:</strong> Kívülről hozzáférhetetlen
              </li>
              <li>
                <strong>Anti-drill védelem:</strong> Fúrás elleni védelem
              </li>
              <li>
                <strong>Pánikzár:</strong> Vészhelyzeti gyors kinyitás
              </li>
            </ul>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Környezetbarát technológiák</h2>
        <div className="bg-green-50 p-6 rounded-lg mb-6">
          <h3 className="font-bold text-lg mb-3">Fenntartható megoldások</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
              <div>
                <strong>Újrahasznosítható anyagok:</strong> 100%-ban újrahasznosítható PVC profilok
              </div>
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
              <div>
                <strong>Ólommentes stabilizátorok:</strong> Környezetbarát adalékanyagok
              </div>
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3"></span>
              <div>
                <strong>Energiahatékony gyártás:</strong> Csökkentett CO₂ kibocsátás
              </div>
            </li>
          </ul>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Oknoplast K+F központ innovációi</h2>
        <div className="bg-primary/10 p-6 rounded-lg mb-6">
          <div className="flex items-start mb-4">
            <Zap className="h-6 w-6 text-primary mr-3 mt-1" />
            <div>
              <h3 className="font-bold text-lg mb-2">Krakkói Innovációs Központ</h3>
              <p className="text-gray-700">
                Az Oknoplast saját kutatás-fejlesztési központjában dolgozó mérnökök és tudósok folyamatosan fejlesztik
                a jövő ablakait.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-bold mb-2">Legújabb fejlesztések</h4>
              <ul className="space-y-1 text-sm">
                <li>• Winergetic Premium 7 kamrás profil</li>
                <li>• Termo HS hőszigetelő betétek</li>
                <li>• Smart Glass intelligens üvegezés</li>
                <li>• Eco-Line környezetbarát sorozat</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Díjak és elismerések</h4>
              <ul className="space-y-1 text-sm">
                <li>• Red Dot Design Award</li>
                <li>• Innovációs díj - Bau München</li>
                <li>• Passzívház Intézet tanúsítvány</li>
                <li>• Európai Minőségi Díj</li>
              </ul>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">A jövő ablakjai</h2>
        <div className="bg-accent/10 p-6 rounded-lg mb-8">
          <h3 className="text-xl font-bold text-primary mb-3">🚀 Fejlesztés alatt álló technológiák</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="space-y-2">
              <li>• Napelemes üvegfelületek</li>
              <li>• Holografikus kijelzők</li>
              <li>• Öngyógyító felületek</li>
            </ul>
            <ul className="space-y-2">
              <li>• AI-vezérelt klimatizálás</li>
              <li>• Levegőtisztító ablakok</li>
              <li>• Hangelnyelő technológia</li>
            </ul>
          </div>
        </div>

        <div className="bg-primary/10 p-6 rounded-lg mb-8">
          <h3 className="text-xl font-bold text-primary mb-3">🏆 Oknoplast technológiai vezetés</h3>
          <p className="mb-3">30+ év kutatás-fejlesztési tapasztalat eredményei:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="space-y-2">
              <li>
                ✓ <strong>Winergetic Premium:</strong> 0,6 W/m²K U-érték
              </li>
              <li>
                ✓ <strong>Termo HS:</strong> Hőszigetelő acélbetétek
              </li>
              <li>
                ✓ <strong>Smart Vent:</strong> Intelligens szellőzés
              </li>
              <li>
                ✓ <strong>Security Plus:</strong> RC2/RC3 biztonsági osztály
              </li>
            </ul>
            <ul className="space-y-2">
              <li>
                ✓ <strong>Eco-Line:</strong> 100% újrahasznosítható
              </li>
              <li>
                ✓ <strong>Color Plus:</strong> 60+ színválaszték
              </li>
              <li>
                ✓ <strong>Glass Tech:</strong> Tripla üvegezés argonnal
              </li>
              <li>
                ✓ <strong>Auto-Close:</strong> Automatikus zárási rendszer
              </li>
            </ul>
          </div>
          <div className="mt-4 p-4 bg-white rounded-lg">
            <p className="text-sm text-gray-600 italic">
              "Az Oknoplast minden évben bevételének 3%-át fordítja kutatás-fejlesztésre, hogy ügyfelei mindig a
              legmodernebb technológiákhoz jussanak hozzá."
            </p>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link href="/kapcsolat" className="btn-primary mr-4">
            Technológiai konzultáció
          </Link>
          <Link href="/termekeink" className="btn-secondary">
            Innovatív termékek
          </Link>
        </div>
      </div>
    </div>
  )
}
