import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Clock, User, Calendar, Home, Users, Droplets, Shield } from "lucide-react"

export default function AblakcsereutMutato() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link href="/blog" className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a bloghoz
        </Link>

        <div className="mb-6">
          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">ÚTMUTATÓ</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Útmutató – Ablakcsere</h1>

        <div className="flex items-center space-x-6 text-gray-600 mb-8">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            <span>2024. január 28.</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-2" />
            <span>10 perc olvasás</span>
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            <span>Oknoplast Szakértő</span>
          </div>
        </div>
      </div>

      <div className="relative h-96 mb-8 rounded-lg overflow-hidden">
        <Image
          src="/images/oknoplast-group-1.png"
          alt="Ablakcsere útmutató - Oknoplast szakértői tanácsok"
          fill
          className="object-cover"
        />
      </div>

      <div className="max-w-4xl mx-auto prose prose-lg">
        <p className="text-xl text-gray-700 mb-6">
          Az ablakcsere jelentős beruházás, amely alaposan megtervezett folyamatot igényel. Az Oknoplast, mint
          Lengyelország legnagyobb ablakgyártója és Európa-szerte elismert prémium márka, több mint 30 éves
          tapasztalattal segíti ügyfeleit a tökéletes megoldás megtalálásában. Ez az útmutató segít eligazodni a
          különböző helyzetekben.
        </p>

        <h2 className="text-2xl font-bold text-primary mb-4">1. Ablakcsere régi házban - Mire kell figyelni?</h2>

        <div className="bg-gray-50 p-6 rounded-lg mb-6">
          <div className="flex items-start mb-4">
            <Home className="h-6 w-6 text-primary mr-3 mt-1" />
            <div>
              <h3 className="font-bold text-lg mb-2">Régi házak speciális kihívásai</h3>
              <p className="text-gray-700">
                A régi épületekben az ablakcsere során különös figyelmet kell fordítani a falszerkezetre, a
                hőszigetelésre és a műemlékvédelmi előírásokra.
              </p>
            </div>
          </div>

          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
              <div>
                <strong>Falvastagság ellenőrzése:</strong> A régi falak gyakran vastagabbak, speciális tokokat
                igényelhetnek
              </div>
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
              <div>
                <strong>Hőszigetelés:</strong> A régi falszerkezet hőhidakat okozhat, külön szigetelés szükséges
              </div>
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 bg-primary rounded-full mt-2 mr-3"></span>
              <div>
                <strong>Műemlékvédelem:</strong> Védett épületeknél előzetes engedély szükséges
              </div>
            </li>
          </ul>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">2. Ablakcsere társasházban - Lépésről lépésre</h2>

        <div className="bg-accent/10 p-6 rounded-lg mb-6">
          <div className="flex items-start mb-4">
            <Users className="h-6 w-6 text-primary mr-3 mt-1" />
            <div>
              <h3 className="font-bold text-lg mb-2">Társasházi ablakcsere folyamata</h3>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-start">
              <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                1
              </div>
              <div>
                <h4 className="font-bold">Közgyűlési határozat</h4>
                <p className="text-sm text-gray-600">Társasházi közgyűlésen kell dönteni a homlokzati ablakcseréről</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                2
              </div>
              <div>
                <h4 className="font-bold">Engedélyek beszerzése</h4>
                <p className="text-sm text-gray-600">Építési engedély vagy egyszerű bejelentés szükséges</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                3
              </div>
              <div>
                <h4 className="font-bold">Koordináció</h4>
                <p className="text-sm text-gray-600">Lakók közötti egyeztetés az időpontokról és részletekről</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold mr-3 mt-0.5">
                4
              </div>
              <div>
                <h4 className="font-bold">Kivitelezés</h4>
                <p className="text-sm text-gray-600">Szakszerű beépítés minimális zavarással</p>
              </div>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">3. Külső redőnyök kiválasztása</h2>
        <p className="mb-4">Az ablakcsere ideális időpontja a külső redőnyök felszerelésére is:</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="border border-gray-200 p-6 rounded-lg">
            <h4 className="font-bold text-lg mb-3 flex items-center">
              <Shield className="h-5 w-5 text-primary mr-2" />
              Alumínium redőnyök
            </h4>
            <ul className="space-y-2 text-sm">
              <li>• Tartós, időjárásálló</li>
              <li>• Karbantartásmentes</li>
              <li>• Kiváló hőszigetelés</li>
              <li>• Automatizálható</li>
            </ul>
          </div>
          <div className="border border-gray-200 p-6 rounded-lg">
            <h4 className="font-bold text-lg mb-3">Előnyök</h4>
            <ul className="space-y-2 text-sm">
              <li>• 30-40% energiamegtakarítás</li>
              <li>• Betörésvédelem</li>
              <li>• Zajcsökkentés</li>
              <li>• UV védelem</li>
            </ul>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">4. Megfelelő fürdőszobai ablak kiválasztása</h2>

        <div className="bg-blue-50 p-6 rounded-lg mb-6">
          <div className="flex items-start mb-4">
            <Droplets className="h-6 w-6 text-blue-600 mr-3 mt-1" />
            <div>
              <h3 className="font-bold text-lg mb-2">Fürdőszobai ablakok speciális követelményei</h3>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-bold mb-2">Technikai követelmények</h4>
              <ul className="space-y-1 text-sm">
                <li>• Páraálló profilok</li>
                <li>• Kondenzációmentes üvegezés</li>
                <li>• Szellőzési lehetőség</li>
                <li>• Könnyű tisztíthatóság</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Magánszféra védelem</h4>
              <ul className="space-y-1 text-sm">
                <li>• Matt vagy mintás üveg</li>
                <li>• Magasabb elhelyezés</li>
                <li>• Speciális kilincsek</li>
                <li>• Redőny vagy roló</li>
              </ul>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Ablakcsere költségei és megtérülés</h2>

        <div className="bg-primary/10 p-6 rounded-lg mb-6">
          <h3 className="text-xl font-bold text-primary mb-3">💰 Költségkalkulátor (átlagos értékek):</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-bold mb-2">Ablakcsere költségei</h4>
              <ul className="space-y-2">
                <li>
                  Műanyag ablak: <strong>80.000-150.000 Ft/m²</strong>
                </li>
                <li>
                  Alumínium ablak: <strong>120.000-200.000 Ft/m²</strong>
                </li>
                <li>
                  Beépítés: <strong>15.000-25.000 Ft/m²</strong>
                </li>
                <li>
                  Külső redőny: <strong>40.000-80.000 Ft/m²</strong>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Megtérülés</h4>
              <ul className="space-y-2">
                <li>
                  Energiamegtakarítás: <strong>30-50%</strong>
                </li>
                <li>
                  Megtérülési idő: <strong>8-12 év</strong>
                </li>
                <li>
                  Ingatlanérték növekedés: <strong>5-10%</strong>
                </li>
                <li>
                  Komfortjavulás: <strong>Felbecsülhetetlen</strong>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Mikor érdemes ablakot cserélni?</h2>
        <div className="bg-gray-50 p-6 rounded-lg mb-6">
          <h3 className="font-bold text-lg mb-3">Jelzések, hogy ideje az ablakcserének:</h3>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <li>• Huzat érezhető</li>
            <li>• Kondenzáció az üvegen</li>
            <li>• Nehezen nyíló/záródó szárnyak</li>
            <li>• Magas fűtési költségek</li>
            <li>• Külső zaj bejutása</li>
            <li>• Régi, elhasználódott megjelenés</li>
            <li>• Biztonsági hiányosságok</li>
            <li>• 20+ éves ablakok</li>
          </ul>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Oknoplast minőségi garancia</h2>
        <div className="bg-accent/10 p-6 rounded-lg mb-6">
          <h3 className="text-xl font-bold text-primary mb-3">🏭 Lengyel gyártási kiválóság</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-bold mb-2">Gyártási szabványok</h4>
              <ul className="space-y-1 text-sm">
                <li>• RAL minőségi tanúsítvány</li>
                <li>• CE megfelelőségi nyilatkozat</li>
                <li>• Passzívház Intézet tanúsítvány</li>
                <li>• Folyamatos minőségellenőrzés</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Technológiai előnyök</h4>
              <ul className="space-y-1 text-sm">
                <li>• Automatizált gyártósorok</li>
                <li>• Precíziós hegesztési technológia</li>
                <li>• Többlépcsős minőségellenőrzés</li>
                <li>• Környezetbarát gyártási folyamat</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-accent/10 p-6 rounded-lg mb-8">
          <h3 className="text-xl font-bold text-primary mb-3">🌟 Oknoplast Debrecen - Lengyel minőség helyben</h3>
          <p className="mb-3">Az Oknoplast hivatalos magyarországi partnereként garantáljuk:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="space-y-2">
              <li>✓ Eredeti lengyel gyártású termékek</li>
              <li>✓ Gyártói 15 év garancia</li>
              <li>✓ Európai szabványok szerinti beépítés</li>
              <li>✓ Szakképzett, tanúsított szerelők</li>
            </ul>
            <ul className="space-y-2">
              <li>✓ Ingyenes 3D tervezés</li>
              <li>✓ Teljes körű projektmenedzsment</li>
              <li>✓ Gyors szállítási idők</li>
              <li>✓ Utólagos szervizszolgáltatás</li>
            </ul>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link href="/kapcsolat" className="btn-primary mr-4">
            Ingyenes felmérés kérése
          </Link>
          <Link href="/szolgaltatasok" className="btn-secondary">
            Szolgáltatások
          </Link>
        </div>
      </div>
    </div>
  )
}
