import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Clock, User, Calendar, CheckCircle, AlertTriangle, Star } from "lucide-react"

export default function AblakvasarlasFolyamata() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link href="/blog" className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a bloghoz
        </Link>

        <div className="mb-6">
          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">ÚTMUTATÓ</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Útmutató – Az ablakvásárlás folyamata</h1>

        <div className="flex items-center space-x-6 text-gray-600 mb-8">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            <span>2024. január 25.</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-2" />
            <span>12 perc olvasás</span>
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            <span>Oknoplast Szakértő</span>
          </div>
        </div>
      </div>

      <div className="relative h-96 mb-8 rounded-lg overflow-hidden">
        <Image
          src="/images/oknoplast-windows.jpg"
          alt="Ablakvásárlás folyamata - Oknoplast minőségi ablakok"
          fill
          className="object-cover"
        />
      </div>

      <div className="max-w-4xl mx-auto prose prose-lg">
        <p className="text-xl text-gray-700 mb-6">
          Az ablakvásárlás komplex folyamat, amely alapos tervezést és megfontolt döntéseket igényel. Az Oknoplast, mint
          Európa egyik vezető lengyel ablakgyártója, több mint 30 éves tapasztalattal rendelkezik a prémium minőségű
          nyílászárók gyártásában. Ez az átfogó útmutató végigvezeti Önt a teljes folyamaton, a tervezéstől a
          beépítésig.
        </p>

        <h2 className="text-2xl font-bold text-primary mb-4">1. Hogyan válasszunk nyílászárókat?</h2>
        <p className="mb-4">A nyílászárók kiválasztása során több tényezőt kell figyelembe venni:</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
              Technikai szempontok
            </h3>
            <ul className="space-y-2 text-sm">
              <li>• Hőszigetelési tulajdonságok (U-érték)</li>
              <li>• Hangszigetelés</li>
              <li>• Biztonsági osztály</li>
              <li>• Szellőzési lehetőségek</li>
            </ul>
          </div>
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-bold text-lg mb-3 flex items-center">
              <Star className="h-5 w-5 text-accent mr-2" />
              Esztétikai szempontok
            </h3>
            <ul className="space-y-2 text-sm">
              <li>• Színválaszték</li>
              <li>• Üvegezési opciók</li>
              <li>• Kilincs és vasalat típusa</li>
              <li>• Építészeti stílushoz illeszkedés</li>
            </ul>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">2. Mire érdemes figyelni az ablakok kiválasztásakor?</h2>

        <div className="bg-accent/10 p-6 rounded-lg mb-6">
          <h3 className="text-xl font-bold text-primary mb-3">🔍 Kulcsfontosságú szempontok:</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
              <div>
                <strong>Energiahatékonyság:</strong> Válasszon alacsony U-értékű ablakokat (0,9 W/m²K alatt)
              </div>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
              <div>
                <strong>Tartósság:</strong> Minőségi profilok és vasalatok hosszú élettartamot biztosítanak
              </div>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
              <div>
                <strong>Karbantartás:</strong> Könnyen tisztítható felületek és működtethető szerkezetek
              </div>
            </li>
          </ul>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">3. Ablakkiegészítők - Alkossuk meg a saját ablakot</h2>
        <p className="mb-4">A modern ablakok számos kiegészítővel testreszabhatók:</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="border border-gray-200 p-4 rounded-lg">
            <h4 className="font-bold mb-2">Üvegezési opciók</h4>
            <ul className="text-sm space-y-1">
              <li>• Hőszigetelő üveg</li>
              <li>• Biztonsági üveg</li>
              <li>• Díszüveg</li>
              <li>• Önttisztító üveg</li>
            </ul>
          </div>
          <div className="border border-gray-200 p-4 rounded-lg">
            <h4 className="font-bold mb-2">Vasalatok</h4>
            <ul className="text-sm space-y-1">
              <li>• Mikroszellőzés</li>
              <li>• Biztonsági vasalat</li>
              <li>• Rejtett zsanérok</li>
              <li>• Automatikus zárás</li>
            </ul>
          </div>
          <div className="border border-gray-200 p-4 rounded-lg">
            <h4 className="font-bold mb-2">Kiegészítők</h4>
            <ul className="text-sm space-y-1">
              <li>• Szúnyogháló</li>
              <li>• Külső redőny</li>
              <li>• Párkány</li>
              <li>• Ablakdísz</li>
            </ul>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">4. Milyen külső redőnyöket érdemes választani?</h2>
        <p className="mb-4">
          A külső redőnyök nemcsak árnyékolást biztosítanak, hanem növelik az épület energiahatékonyságát is:
        </p>

        <ul className="list-disc pl-6 mb-6">
          <li>
            <strong>Alumínium redőnyök:</strong> Tartósak, karbantartásmentesek, különböző színekben
          </li>
          <li>
            <strong>PVC redőnyök:</strong> Jó ár-érték arány, könnyű szerelés
          </li>
          <li>
            <strong>Fa redőnyök:</strong> Természetes megjelenés, jó hőszigetelés
          </li>
          <li>
            <strong>Automatizált redőnyök:</strong> Kényelmes használat, időzíthető működés
          </li>
        </ul>

        <h2 className="text-2xl font-bold text-primary mb-4">5. Mikor érdemes beépíteni az ablakokat?</h2>

        <div className="bg-primary/10 p-6 rounded-lg mb-6">
          <h3 className="text-xl font-bold text-primary mb-3">📅 Optimális időpontok:</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-bold mb-2">Tavasz (március-május)</h4>
              <ul className="text-sm space-y-1">
                <li>• Ideális időjárási viszonyok</li>
                <li>• Gyors száradás</li>
                <li>• Felkészülés a nyárra</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-2">Ősz (szeptember-november)</h4>
              <ul className="text-sm space-y-1">
                <li>• Stabil időjárás</li>
                <li>• Felkészülés a télre</li>
                <li>• Kedvezőbb árak</li>
              </ul>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">6. Hogyan válasszunk ablakgyártót?</h2>

        <div className="bg-gray-50 p-6 rounded-lg mb-6">
          <h3 className="text-xl font-bold text-primary mb-3">✅ Ellenőrizendő szempontok:</h3>
          <ul className="space-y-2">
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-1" />
              <span>
                <strong>Referenciák:</strong> Korábbi munkák megtekintése, ügyfélvélemények
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-1" />
              <span>
                <strong>Garancia:</strong> Minimum 10 év garancia a termékre és munkára
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-1" />
              <span>
                <strong>Tanúsítványok:</strong> CE jelölés, ISO tanúsítványok
              </span>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-1" />
              <span>
                <strong>Szerviz:</strong> Utólagos karbantartás és javítás lehetősége
              </span>
            </li>
          </ul>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">7. Mielőtt ablakot vásárol - Fontos tudnivalók</h2>

        <div className="bg-red-50 border-l-4 border-red-400 p-6 mb-6">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-red-400 mr-2 mt-0.5" />
            <div>
              <h3 className="font-bold text-red-800 mb-2">Gyakori hibák, amiket kerülni kell:</h3>
              <ul className="text-red-700 space-y-1">
                <li>• Csak az ár alapján történő döntés</li>
                <li>• Szakértői tanácsadás mellőzése</li>
                <li>• Nem megfelelő méretek megadása</li>
                <li>• Beépítési költségek figyelmen kívül hagyása</li>
              </ul>
            </div>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">8. Oknoplast technológiai előnyök</h2>
        <div className="bg-primary/10 p-6 rounded-lg mb-6">
          <h3 className="text-xl font-bold text-primary mb-3">🔬 Lengyel innovációs központ eredményei:</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
              <div>
                <strong>Winergetic Premium:</strong> Saját fejlesztésű 7 kamrás profilrendszer, 0,6 W/m²K U-értékkel
              </div>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
              <div>
                <strong>Termo HS:</strong> Hőszigetelő betétek a profilokban a maximális energiahatékonyságért
              </div>
            </li>
            <li className="flex items-start">
              <CheckCircle className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
              <div>
                <strong>Siegenia vasalatok:</strong> Német prémium vasalatok 20 éves élettartam garanciával
              </div>
            </li>
          </ul>
        </div>

        <h2 className="text-2xl font-bold text-primary mb-4">Miért válassza az Oknoplast lengyel minőséget?</h2>
        <div className="bg-accent/10 p-6 rounded-lg mb-8">
          <h3 className="text-xl font-bold text-primary mb-3">🏆 Lengyel prémium minőség Debrecenben</h3>
          <p className="mb-4">
            Az Oknoplast 1994 óta Európa egyik vezető ablakgyártója. A lengyel precizitás és német technológia ötvözete.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="space-y-2">
              <li>✓ 30+ év gyártási tapasztalat</li>
              <li>✓ Európai minőségi szabványok</li>
              <li>✓ Saját kutatás-fejlesztési központ</li>
              <li>✓ ISO 9001, 14001 tanúsítványok</li>
            </ul>
            <ul className="space-y-2">
              <li>✓ Winergetic prémium profilrendszer</li>
              <li>✓ 15 év teljes körű gyártói garancia</li>
              <li>✓ Több mint 15 országban jelen</li>
              <li>✓ Folyamatos innovációs díjak</li>
            </ul>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link href="/kapcsolat" className="btn-primary mr-4">
            Ingyenes konzultáció
          </Link>
          <Link href="/termekeink" className="btn-secondary">
            Termékek megtekintése
          </Link>
        </div>
      </div>
    </div>
  )
}
