"use client"

import { useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ProductComparison from "@/components/product-comparison"
import { useProductsByCategory } from "@/hooks/use-products"
import { curvedWindows } from "@/data/products"

export default function Products() {
  const { productsByCategory, loading, error } = useProductsByCategory()

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const windows = productsByCategory.ablakok || []
  const shutters = productsByCategory.redonyok || []
  const accessories = productsByCategory.accessories || []

  const entranceDoors = [
    {
      id: "bejarati-1",
      name: "Műanyag ajtók",
      description:
        "Kiváló hőszigetelési tulajdonságokkal rendelkező műanyag bejárati ajtók. Energiatakarékos megoldás családi házakhoz, karbantartásmentes felülettel és hosszú élettartammal.",
      image_src: "/images/muanyag-bejarati-ajto.jpg",
      specifications: {
        Anyag: "PVC többkamrás profil",
        Hőszigetelés: "Ud = 1,2 W/m²K",
        Biztonsági: "3 pontos zár",
        Hangszigetelés: "Rw = 35 dB",
        Garancia: "10 év",
      },
      price_range: "mid" as const,
      link: "/termekeink/muanyag-bejarati-ajtok",
    },
    {
      id: "bejarati-2",
      name: "Műanyag Prémium Ajtók",
      description:
        "Prémium kategóriás műanyag bejárati ajtók fokozott biztonsági és hőszigetelési tulajdonságokkal. Modern design és kiváló funkcionalitás jellemzi.",
      image_src: "/images/muanyag-premium-ajto.jpg",
      specifications: {
        Anyag: "PVC Prémium profil",
        Hőszigetelés: "Ud = 1,0 W/m²K",
        Biztonsági: "5 pontos zár RC2",
        Hangszigetelés: "Rw = 38 dB",
        Garancia: "15 év",
      },
      price_range: "premium" as const,
      link: "/termekeink/muanyag-premium-ajtok",
    },
    {
      id: "bejarati-3",
      name: "Alumínium Bejárati ajtók",
      description:
        "Modern alumínium bejárati ajtók tartós szerkezettel és elegáns megjelenéssel. Ideális választás kortárs építészeti stílusokhoz és irodaépületekhez.",
      image_src: "/images/aluminium-bejarati-ajto.jpg",
      specifications: {
        Anyag: "Hőszigetelt alumínium",
        Hőszigetelés: "Ud = 1,1 W/m²K",
        Biztonsági: "3 pontos zár",
        Design: "Modern, minimalista",
        Színek: "RAL színskála",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
    },
    {
      id: "bejarati-4",
      name: "Acél Bejárati ajtók",
      description:
        "Maximális biztonságot nyújtó acél bejárati ajtók fém vagy fa tokkal. Kiváló betörésvédelem és hosszú élettartam jellemzi, különböző design opciókkal.",
      image_src: "/images/acel-bejarati-ajto.jpg",
      specifications: {
        Anyag: "Acél váz + szigetelés",
        Biztonsági: "RC3 osztály",
        Tok: "Fém vagy fa tok",
        Zárrendszer: "7 pontos zár",
        Vastagság: "80-100 mm",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
    },
  ]

  const slidingDoors = [
    {
      id: "tolo-1",
      name: "Emelő-Tolóajtó",
      description:
        "Prémium emelő-toló rendszer nagy méretű üvegfelületekkel. Könnyű kezelhetőség és kiváló szigetelési tulajdonságok jellemzik.",
      image_src: "/images/emelo-toloajto.jpg",
      specifications: {
        Mechanizmus: "Emelő-toló rendszer",
        "Max méret": "Akár 6m széles nyílás",
        Kezelés: "Könnyű, ergonomikus",
        Hőszigetelés: "Passzívház szabvány",
        Üvegezés: "Háromrétegű",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
    },
    {
      id: "tolo-2",
      name: "Slide-Tolóajtó",
      description:
        "Egyszerű és megbízható slide-toló rendszer. Költséghatékony megoldás nagyobb nyílások áthidalására, kiváló funkcionalitással.",
      image_src: "/images/slide-toloajto.jpg",
      specifications: {
        Mechanizmus: "Slide-toló rendszer",
        "Max méret": "Akár 4m széles nyílás",
        Kezelés: "Egyszerű tolás",
        Hőszigetelés: "Jó szigetelés",
        Üvegezés: "Dupla üveg",
      },
      price_range: "mid" as const,
      link: "/kapcsolat",
    },
    {
      id: "tolo-3",
      name: "Bukó-Tolóajtó",
      description:
        "Kombinált bukó-toló rendszer, amely lehetővé teszi mind a bukó, mind a toló nyitást. Kiváló szellőzési lehetőségekkel.",
      image_src: "/images/buko-toloajto.jpg",
      specifications: {
        Mechanizmus: "Bukó-toló kombináció",
        Nyitás: "Bukó és toló funkció",
        Szellőzés: "Kiváló szellőzés",
        Hőszigetelés: "Jó szigetelés",
        Vasalat: "Prémium vasalat",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
    },
    {
      id: "tolo-4",
      name: "Alumínium-Emelő Tolóajtó",
      description:
        "Alumínium szerkezetű emelő-toló ajtó rendszer. Modern megjelenés és kiváló tartósság jellemzi, nagy üvegfelületekkel.",
      image_src: "/images/aluminium-emelo-toloajto.jpg",
      specifications: {
        Anyag: "Hőszigetelt alumínium",
        Mechanizmus: "Emelő-toló rendszer",
        "Max méret": "Akár 8m széles nyílás",
        Design: "Modern, vékony profil",
        Színek: "RAL színskála",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
    },
  ]

  const balconyDoors = [
    {
      id: "erkely-1",
      name: "Standard Tok Küszöbös",
      description:
        "Hagyományos erkélyajtó standard tokkal és küszöbbel. Megbízható megoldás erkélyek és teraszok megközelítésére, kiváló ár-érték aránnyal.",
      image_src: "/images/standard-tok-kuszobo.jpg",
      specifications: {
        Tok: "Standard PVC tok",
        Küszöb: "Hagyományos küszöb",
        Profil: "70mm többkamrás",
        Üvegezés: "Dupla üveg",
        Vasalat: "Standard vasalat",
      },
      price_range: "mid" as const,
      link: "/kapcsolat",
    },
    {
      id: "erkely-2",
      name: "Alacsony Aluminium Küszöbös - Erkélyajtó",
      description:
        "Modern erkélyajtó alacsony alumínium küszöbbel. Akadálymentes átjárást biztosít, ideális idősebb személyek és mozgáskorlátozottak számára.",
      image_src: "/images/alacsony-kuszobo-erkely.jpg",
      specifications: {
        Küszöb: "Alacsony alumínium küszöb",
        "Küszöb magasság": "15-20 mm",
        Akadálymentesítés: "Igen",
        Vízzárás: "Kiváló vízzárás",
        Hőszigetelés: "Jó szigetelés",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
    },
    {
      id: "erkely-3",
      name: "Átmenő Kilincses - Erkélyajtó",
      description:
        "Speciális átmenő kilincses erkélyajtó, amely mindkét oldalról nyitható. Praktikus megoldás gyakran használt átjárókhoz.",
      image_src: "/images/atmeno-kilincses-erkely.jpg",
      specifications: {
        Kilincs: "Átmenő kilincses rendszer",
        Nyitás: "Mindkét irányból nyitható",
        Biztonsági: "Dupla zárási pont",
        Használat: "Gyakori használatra",
        Vasalat: "Megerősített vasalat",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
    },
  ]

  const pergolaCategories = [
    {
      id: "pergola-1",
      name: "Fix tetős megoldások",
      description:
        "Tartós és megbízható fix tetős pergolák, amelyek állandó árnyékolást és védelmet biztosítanak. Ideális választás azok számára, akik egyszerű, karbantartásmentes megoldást keresnek teraszukra vagy kertjükbe.",
      image_src: "/images/pergola-fix-tetos.jpg",
      specifications: {
        Szerkezet: "Porbevonatolt alumínium váz",
        Fedőanyag: "Polikarbonát vagy üveglemez",
        Tartósság: "25 év szerkezeti garancia",
        Karbantartás: "Minimális karbantartás igény",
        Méretezés: "Egyedi méretekben készül",
      },
      price_range: "mid" as const,
      link: "/kapcsolat",
      features: [
        "Időjárásálló alumínium szerkezet",
        "Választható fedőanyagok",
        "Egyedi színek és méretek",
        "Gyors és egyszerű telepítés",
        "Hosszú élettartam",
      ],
    },
    {
      id: "pergola-2",
      name: "Bioklimatikus pergola lamellás",
      description:
        "Intelligens lamellás pergola rendszer, amely lehetővé teszi a fény és szellőzés precíz szabályozását. A forgatható lamellák segítségével tökéletesen alkalmazkodhat az időjárási viszonyokhoz és személyes igényeihez.",
      image_src: "/images/pergola-bioklimatikus.jpg",
      specifications: {
        "Lamella rendszer": "Forgatható alumínium lamellák",
        Vízelvezetés: "Integrált csatornarendszer",
        Vezérlés: "Kézi vagy motoros működtetés",
        "Szellőzés szabályozás": "0-90° lamella állítás",
        "Időjárás érzékelő": "Opcionális automata vezérlés",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
      features: [
        "Állítható lamellák 0-90° között",
        "Integrált vízelvezető rendszer",
        "Motoros vagy kézi vezérlés",
        "Időjárás érzékelő opció",
        "Tökéletes fény- és szellőzésszabályozás",
      ],
    },
    {
      id: "pergola-3",
      name: "Hőszigetelt Télikert rendszerek",
      description:
        "Prémium hőszigetelt télikert rendszerek, amelyek lehetővé teszik a külső terek egész éves használatát. Kiváló hőszigetelési tulajdonságokkal és modern technológiával felszerelt megoldások a maximális komfort érdekében.",
      image_src: "/images/telikert-rendszer.jpg",
      specifications: {
        Hőszigetelés: "Háromrétegű üvegezés",
        "Profil rendszer": "Hőszigetelt alumínium profil",
        Fűtés: "Padlófűtés kompatibilis",
        Szellőzés: "Automatikus szellőzőrendszer",
        "Hőmérséklet szabályozás": "Intelligens klíma vezérlés",
      },
      price_range: "premium" as const,
      link: "/kapcsolat",
      features: [
        "Egész éves használhatóság",
        "Kiváló hőszigetelési értékek",
        "Automatikus klíma szabályozás",
        "Padlófűtés kompatibilitás",
        "Prémium üvegezési megoldások",
      ],
    },
  ]

  if (loading) {
    return (
      <div className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <p>Termékek betöltése...</p>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center text-red-600">
            <p>Hiba történt a termékek betöltése során: {error}</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="pt-32 pb-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-primary text-center mb-8 md:mb-12">Termékeink</h1>

        <Tabs defaultValue="windows" className="w-full">
          <div className="overflow-x-auto mb-6 md:mb-8">
            <TabsList className="grid w-full grid-cols-8 h-auto min-w-[800px]">
              <TabsTrigger value="windows" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                Ablakok ({windows.length})
              </TabsTrigger>
              <TabsTrigger value="entrance-doors" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                🚪 Bejárati ajtók ({entranceDoors.length})
              </TabsTrigger>
              <TabsTrigger value="sliding-doors" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                ↔️ Tolóajtók ({slidingDoors.length})
              </TabsTrigger>
              <TabsTrigger value="balcony-doors" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                🏠 Erkélyajtók ({balconyDoors.length})
              </TabsTrigger>
              <TabsTrigger value="shutters" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                Redőnyök ({shutters.length})
              </TabsTrigger>
              <TabsTrigger value="accessories" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                Kiegészítők ({accessories.length})
              </TabsTrigger>
              <TabsTrigger value="pergolas" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                Pergolák ({pergolaCategories.length})
              </TabsTrigger>
              <TabsTrigger value="comparison" className="text-xs md:text-sm p-2 md:p-3 whitespace-nowrap">
                Összehasonlítás
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="windows" className="animate-fade-in">
            <div className="mb-8 md:mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-primary mb-6 md:mb-8">
                Modern műanyag ablakok ({windows.length} termék)
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {windows.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>

            <section className="bg-gray-50 rounded-2xl p-8 md:p-12">
              <h2 className="text-2xl md:text-3xl font-bold text-primary text-center mb-8">
                Nem négyszög alakú szerkezetek
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {curvedWindows.map((window, index) => (
                  <div key={index} className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
                    <h3 className="text-lg font-bold text-primary mb-3">{window.name}</h3>
                    <p className="text-gray-600 text-sm mb-4 leading-relaxed">{window.description}</p>
                    <ul className="space-y-2 mb-6">
                      {window.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="text-sm text-gray-700 flex items-start">
                          <span className="w-1.5 h-1.5 bg-[#FFD700] rounded-full mr-2 mt-2 flex-shrink-0"></span>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Link
                      href="/kapcsolat"
                      className="inline-block px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors text-sm font-medium"
                    >
                      Érdeklődöm →
                    </Link>
                  </div>
                ))}
              </div>

              <div className="text-center mt-8">
                <p className="text-gray-600 mb-4">
                  Minden speciális formájú ablak egyedi tervezés és gyártás alapján készül.
                </p>
                <Link
                  href="/kapcsolat"
                  className="inline-block px-8 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-semibold"
                >
                  Egyedi ajánlatkérés
                </Link>
              </div>
            </section>
          </TabsContent>

          <TabsContent value="entrance-doors" className="animate-fade-in">
            <div className="mb-8 md:mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-primary mb-6 md:mb-8 text-center">
                🚪 Bejárati ajtók ({entranceDoors.length} termék)
              </h2>
              <p className="text-gray-600 mb-8 text-center max-w-4xl mx-auto">
                Biztonságos és energiatakarékos bejárati ajtók széles választéka. Műanyag, alumínium és acél kivitelben,
                minden biztonsági és design igényhez.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
                {entranceDoors.map((product) => (
                  <CategoryProductCard key={product.id} product={product} />
                ))}
              </div>

              <div className="text-center mt-12">
                <div className="bg-blue-50 rounded-xl p-8 mb-8">
                  <h3 className="text-xl font-semibold text-primary mb-4">Miért válassza bejárati ajtóinkat?</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-sm">
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">RC2-RC3 biztonság</span>
                      <span className="text-gray-600 text-xs mt-1">Betörésvédelem</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Kiváló hőszigetelés</span>
                      <span className="text-gray-600 text-xs mt-1">Energiatakarékosság</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Egyedi méretek</span>
                      <span className="text-gray-600 text-xs mt-1">Minden nyíláshoz</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">10-15 év garancia</span>
                      <span className="text-gray-600 text-xs mt-1">Hosszú távú védelem</span>
                    </div>
                  </div>
                </div>
                <Link
                  href="/kapcsolat"
                  className="inline-block px-8 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-semibold text-lg"
                >
                  Kérjen ajánlatot bejárati ajtóra
                </Link>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sliding-doors" className="animate-fade-in">
            <div className="mb-8 md:mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-primary mb-6 md:mb-8 text-center">
                ↔️ Tolóajtók ({slidingDoors.length} termék)
              </h2>
              <p className="text-gray-600 mb-8 text-center max-w-4xl mx-auto">
                Modern tolóajtó rendszerek nagy üvegfelületekkel. Emelő-toló, slide és bukó-toló megoldások minden
                igényhez és mérethez.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
                {slidingDoors.map((product) => (
                  <CategoryProductCard key={product.id} product={product} />
                ))}
              </div>

              <div className="text-center mt-12">
                <div className="bg-green-50 rounded-xl p-8 mb-8">
                  <h3 className="text-xl font-semibold text-primary mb-4">Tolóajtók előnyei</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-sm">
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Nagy üvegfelületek</span>
                      <span className="text-gray-600 text-xs mt-1">Maximális fény</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Helytakarékos</span>
                      <span className="text-gray-600 text-xs mt-1">Nincs nyitási ív</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Könnyű kezelés</span>
                      <span className="text-gray-600 text-xs mt-1">Ergonomikus működés</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Akár 8m széles</span>
                      <span className="text-gray-600 text-xs mt-1">Nagy nyílások</span>
                    </div>
                  </div>
                </div>
                <Link
                  href="/kapcsolat"
                  className="inline-block px-8 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-semibold text-lg"
                >
                  Kérjen ajánlatot tolóajtóra
                </Link>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="balcony-doors" className="animate-fade-in">
            <div className="mb-8 md:mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-primary mb-6 md:mb-8 text-center">
                🏠 Erkélyajtók ({balconyDoors.length} termék)
              </h2>
              <p className="text-gray-600 mb-8 text-center max-w-4xl mx-auto">
                Praktikus erkélyajtók különböző küszöb megoldásokkal. Standard, alacsony küszöbös és átmenő kilincses
                változatok minden igényhez.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {balconyDoors.map((product) => (
                  <CategoryProductCard key={product.id} product={product} />
                ))}
              </div>

              <div className="text-center mt-12">
                <div className="bg-orange-50 rounded-xl p-8 mb-8">
                  <h3 className="text-xl font-semibold text-primary mb-4">Erkélyajtók specialitásai</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Akadálymentes</span>
                      <span className="text-gray-600 text-xs mt-1">Alacsony küszöb opció</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Vízzáró</span>
                      <span className="text-gray-600 text-xs mt-1">Kiváló tömítés</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Kétirányú nyitás</span>
                      <span className="text-gray-600 text-xs mt-1">Átmenő kilincs</span>
                    </div>
                  </div>
                </div>
                <Link
                  href="/kapcsolat"
                  className="inline-block px-8 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-semibold text-lg"
                >
                  Kérjen ajánlatot erkélyajtóra
                </Link>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="shutters" className="animate-fade-in">
            <div className="mb-8 md:mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-primary mb-6 md:mb-8">
                Redőnyök ({shutters.length} termék)
              </h2>
              <p className="text-gray-600 mb-8 text-center max-w-3xl mx-auto">
                Redőnyeink kiváló árnyékolást és hőszigetelést biztosítanak. Modern technológiával és elegáns designnal.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {shutters.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="accessories" className="animate-fade-in">
            <div className="mb-8 md:mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-primary mb-6 md:mb-8">
                Kiegészítők ({accessories.length} termék)
              </h2>
              <p className="text-gray-600 mb-8 text-center max-w-3xl mx-auto">
                Kiegészítőink tökéletesen kiegészítik ablak- és ajtórendszereinket. Praktikus megoldások minden
                igényhez.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {accessories.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="pergolas" className="animate-fade-in">
            <div className="mb-8 md:mb-12">
              <h2 className="text-xl md:text-2xl font-bold text-primary mb-6 md:mb-8">
                Pergolák - Alumínium Előtetők ({pergolaCategories.length} kategória)
              </h2>
              <p className="text-gray-600 mb-8 text-center max-w-4xl mx-auto">
                Pergola és alumínium előtető megoldásaink három fő kategóriában érhetők el. Minden kategória egyedi
                előnyöket és funkciókat kínál, hogy tökéletesen illeszkedjen az Ön igényeihez és a helyi adottságokhoz.
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10">
                {pergolaCategories.map((category) => (
                  <PergolaCategory key={category.id} category={category} />
                ))}
              </div>

              <div className="text-center mt-12">
                <div className="bg-green-50 rounded-xl p-8 mb-8">
                  <h3 className="text-xl font-semibold text-primary mb-4">Miért válassza pergola megoldásainkat?</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-sm">
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Időjárásálló anyagok</span>
                      <span className="text-gray-600 text-xs mt-1">25 év garancia</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Egyedi méretezés</span>
                      <span className="text-gray-600 text-xs mt-1">Minden igényhez</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Professzionális telepítés</span>
                      <span className="text-gray-600 text-xs mt-1">Tapasztalt csapat</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <span className="w-3 h-3 bg-[#FFD700] rounded-full mb-2"></span>
                      <span className="font-medium">Teljes körű szerviz</span>
                      <span className="text-gray-600 text-xs mt-1">Karbantartás és javítás</span>
                    </div>
                  </div>
                </div>
                <Link
                  href="/kapcsolat"
                  className="inline-block px-8 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-semibold text-lg"
                >
                  Kérjen személyre szabott ajánlatot
                </Link>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="comparison" className="animate-fade-in">
            <ProductComparison />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function ProductCard({ product }: { product: any }) {
  const specs = product.specifications || {}
  const displaySpecs = Object.entries(specs)
    .slice(0, 4)
    .map(([key, value]) => `${value}`)

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative h-48 md:h-64">
        <Image
          src={product.image_src || "/placeholder.svg?height=300&width=400&text=" + encodeURIComponent(product.name)}
          alt={product.name}
          fill
          className="object-cover"
          crossOrigin="anonymous"
          onError={(e) => {
            const target = e.target as HTMLImageElement
            target.src = "/placeholder.svg?height=300&width=400&text=" + encodeURIComponent(product.name)
          }}
        />
        {product.price_range && (
          <div className="absolute top-2 right-2">
            <span
              className={`px-2 py-1 rounded-full text-xs font-semibold ${
                product.price_range === "premium"
                  ? "bg-[#FFD700] text-[#003366]"
                  : product.price_range === "mid"
                    ? "bg-[#003366] text-white"
                    : "bg-gray-500 text-white"
              }`}
            >
              {product.price_range === "premium" ? "Prémium" : product.price_range === "mid" ? "Közép" : "Alapvető"}
            </span>
          </div>
        )}
      </div>
      <div className="p-4 md:p-6">
        <h3 className="text-lg md:text-xl font-bold text-[#003366] mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4 text-sm md:text-base">{product.description}</p>

        {displaySpecs.length > 0 && (
          <div className="mb-4">
            <h4 className="font-semibold text-sm text-[#003366] mb-2">Főbb jellemzők:</h4>
            <ul className="text-xs md:text-sm text-gray-600 space-y-1">
              {displaySpecs.map((spec, index) => (
                <li key={index} className="flex items-center">
                  <span className="w-1.5 h-1.5 bg-[#FFD700] rounded-full mr-2 flex-shrink-0"></span>
                  {spec}
                </li>
              ))}
            </ul>
          </div>
        )}

        <Link
          href={product.link}
          className="text-[#003366] font-semibold hover:text-[#FFD700] transition-colors text-sm md:text-base"
        >
          {product.link === "/kapcsolat"
            ? "Érdeklődöm →"
            : product.link.startsWith("/termekeink/")
              ? "Részletek →"
              : "Érdeklődöm →"}
        </Link>
      </div>
    </div>
  )
}

function CategoryProductCard({ product }: { product: any }) {
  const specs = product.specifications || {}
  const displaySpecs = Object.entries(specs)
    .slice(0, 4)
    .map(([key, value]) => `${key}: ${value}`)

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-lg transition-transform duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative h-48 md:h-56">
        <Image
          src={product.image_src || "/placeholder.svg?height=300&width=400&text=" + encodeURIComponent(product.name)}
          alt={product.name}
          fill
          className="object-cover"
          crossOrigin="anonymous"
          onError={(e) => {
            const target = e.target as HTMLImageElement
            target.src = "/placeholder.svg?height=300&width=400&text=" + encodeURIComponent(product.name)
          }}
        />
        {product.price_range && (
          <div className="absolute top-2 right-2">
            <span
              className={`px-2 py-1 rounded-full text-xs font-semibold ${
                product.price_range === "premium"
                  ? "bg-[#FFD700] text-[#003366]"
                  : product.price_range === "mid"
                    ? "bg-[#003366] text-white"
                    : "bg-gray-500 text-white"
              }`}
            >
              {product.price_range === "premium" ? "Prémium" : product.price_range === "mid" ? "Közép" : "Alapvető"}
            </span>
          </div>
        )}
      </div>
      <div className="p-4 md:p-6">
        <h3 className="text-lg md:text-xl font-bold text-[#003366] mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4 text-sm md:text-base leading-relaxed">{product.description}</p>

        {displaySpecs.length > 0 && (
          <div className="mb-4">
            <h4 className="font-semibold text-sm text-[#003366] mb-2">Műszaki adatok:</h4>
            <ul className="text-xs md:text-sm text-gray-600 space-y-1">
              {displaySpecs.map((spec, index) => (
                <li key={index} className="flex items-start">
                  <span className="w-1.5 h-1.5 bg-[#FFD700] rounded-full mr-2 mt-2 flex-shrink-0"></span>
                  {spec}
                </li>
              ))}
            </ul>
          </div>
        )}

        <Link
          href={product.link}
          className="inline-block w-full text-center px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-colors text-sm font-medium"
        >
          {product.link === "/kapcsolat"
            ? "Érdeklődöm →"
            : product.link.startsWith("/termekeink/")
              ? "Részletek →"
              : "Érdeklődöm →"}
        </Link>
      </div>
    </div>
  )
}

function PergolaCategory({ category }: { category: any }) {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg transition-transform duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="relative h-64">
        <Image
          src={category.image_src || "/placeholder.svg?height=300&width=400&text=" + encodeURIComponent(category.name)}
          alt={category.name}
          fill
          className="object-cover"
          crossOrigin="anonymous"
          onError={(e) => {
            const target = e.target as HTMLImageElement
            target.src = "/placeholder.svg?height=300&width=400&text=" + encodeURIComponent(category.name)
          }}
        />
        <div className="absolute top-4 right-4">
          <span
            className={`px-3 py-1 rounded-full text-xs font-semibold ${
              category.price_range === "premium" ? "bg-[#FFD700] text-[#003366]" : "bg-[#003366] text-white"
            }`}
          >
            {category.price_range === "premium" ? "Prémium" : "Közép"}
          </span>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-[#003366] mb-3">{category.name}</h3>
        <p className="text-gray-600 mb-6 text-sm leading-relaxed">{category.description}</p>

        <div className="mb-6">
          <h4 className="font-semibold text-sm text-[#003366] mb-3">Főbb jellemzők:</h4>
          <ul className="space-y-2">
            {category.features.map((feature: string, index: number) => (
              <li key={index} className="text-sm text-gray-700 flex items-start">
                <span className="w-1.5 h-1.5 bg-[#FFD700] rounded-full mr-2 mt-2 flex-shrink-0"></span>
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <div className="mb-6">
          <h4 className="font-semibold text-sm text-[#003366] mb-3">Műszaki adatok:</h4>
          <ul className="space-y-1">
            {Object.entries(category.specifications)
              .slice(0, 3)
              .map(([key, value], index) => (
                <li key={index} className="text-xs text-gray-600 flex justify-between">
                  <span className="font-medium">{key}:</span>
                  <span>{value as string}</span>
                </li>
              ))}
          </ul>
        </div>

        <Link
          href={category.link}
          className="inline-block w-full text-center px-4 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors font-semibold"
        >
          Részletes ajánlatkérés →
        </Link>
      </div>
    </div>
  )
}
