import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, CheckCircle, Star, Shield, Lock, Award } from "lucide-react"

export default function MuanyagPremiumAjtok() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link
          href="/termekeink"
          className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a termékekhez
        </Link>

        <div className="mb-6">
          <span className="bg-accent text-primary px-3 py-1 rounded-full text-sm font-semibold">PRÉMIUM AJTÓ</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Műanyag Prémium Ajtók</h1>
        <p className="text-xl text-gray-700 mb-8">
          Prémium kategóriás műanyag bejárati ajtók fokozott biztonsági tulajdonságokkal
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        <div className="relative h-96 rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Prémium+Műanyag+Ajtó"
            alt="Oknoplast prémium műanyag bejárati ajtó"
            fill
            className="object-cover"
          />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-primary mb-4">Prémium minőség minden részletben</h2>
          <p className="mb-6">
            A műanyag prémium ajtók a legmagasabb minőségi követelményeknek megfelelően készülnek. RC3 biztonsági
            osztályú védelem, tripla tömítés és prémium vasalatok jellemzik, amelyek garantálják a hosszú élettartamot
            és a maximális biztonságot.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>RC3 biztonsági osztály</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Tripla tömítés</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Prémium vasalatok</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Kiváló design</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Biztonság</h3>
          <p className="text-sm mb-2">RC3 osztály</p>
          <p className="text-xs text-gray-600">Fokozott védelem</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Lock className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Zárrendszer</h3>
          <p className="text-sm mb-2">5 pontos zár</p>
          <p className="text-xs text-gray-600">Többpontos biztonság</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Star className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Minőség</h3>
          <p className="text-sm mb-2">Prémium anyagok</p>
          <p className="text-xs text-gray-600">Kiváló kivitelezés</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Award className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Garancia</h3>
          <p className="text-sm mb-2">15 év</p>
          <p className="text-xs text-gray-600">Hosszú távú védelem</p>
        </div>
      </div>

      <div className="bg-accent/10 p-8 rounded-lg mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6">Prémium jellemzők</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-bold mb-4">Biztonsági elemek</h3>
            <ul className="space-y-2">
              <li>
                <strong>Biztonsági osztály:</strong> RC3
              </li>
              <li>
                <strong>Zárrendszer:</strong> 5 pontos többzáras
              </li>
              <li>
                <strong>Biztonsági üveg:</strong> P4A osztályú
              </li>
              <li>
                <strong>Rejtett zsanérok:</strong> Betörésbiztos
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4">Komfort jellemzők</h3>
            <ul className="space-y-2">
              <li>
                <strong>Tripla tömítés:</strong> Kiváló szigetelés
              </li>
              <li>
                <strong>Hőátbocsátás:</strong> Ud = 1,0 W/m²K
              </li>
              <li>
                <strong>Hangszigetelés:</strong> Rw = 38 dB
              </li>
              <li>
                <strong>Színválaszték:</strong> 15+ szín
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-2xl font-bold text-primary mb-6">Tapasztalja meg a prémium minőséget!</h2>
        <Link href="/kapcsolat" className="btn-primary">
          Prémium ajtó árajánlat
        </Link>
      </div>
    </div>
  )
}
