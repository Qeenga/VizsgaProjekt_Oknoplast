import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, CheckCircle, Star, Thermometer, Shield, Award, Zap } from "lucide-react"

export default function Winergetic82() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link
          href="/termekeink"
          className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a termékekhez
        </Link>

        <div className="mb-6">
          <span className="bg-accent text-primary px-3 py-1 rounded-full text-sm font-semibold">
            ZÁSZLÓSHAJÓ MODELL
          </span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Winergetic-82</h1>
        <p className="text-xl text-gray-700 mb-8">
          Az Oknoplast zászlóshajó profilrendszere a legmodernebb technológiákkal
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        <div className="relative h-96 rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Winergetic-82+Zászlóshajó"
            alt="Oknoplast Winergetic-82 zászlóshajó ablak"
            fill
            className="object-cover"
          />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-primary mb-4">A technológiai csúcs</h2>
          <p className="mb-6">
            A Winergetic-82 az Oknoplast büszkesége, amely a legmodernebb technológiákat ötvözi egyetlen
            profilrendszerben. A 7 kamrás szerkezet és a Termo HS technológia révén kiváló energiahatékonyságot és
            hosszú élettartamot biztosít minden típusú épülethez.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>7 kamrás profilszerkezet</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Termo HS technológia</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>82 mm beépítési mélység</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Passzívház szabvány</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Thermometer className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Energiahatékonyság</h3>
          <p className="text-sm mb-2">Uw = 0,6 W/m²K</p>
          <p className="text-xs text-gray-600">Kiváló hőszigetelés</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Termo HS</h3>
          <p className="text-sm mb-2">Hőszigetelő betétek</p>
          <p className="text-xs text-gray-600">Innovatív technológia</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Award className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Tanúsítványok</h3>
          <p className="text-sm mb-2">Passzívház Intézet</p>
          <p className="text-xs text-gray-600">Nemzetközi elismerés</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Zap className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Élettartam</h3>
          <p className="text-sm mb-2">50+ év</p>
          <p className="text-xs text-gray-600">Hosszú távú befektetés</p>
        </div>
      </div>

      <div className="bg-primary/10 p-8 rounded-lg mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6">Termo HS technológia</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-bold mb-4">Innovatív megoldások</h3>
            <ul className="space-y-2">
              <li>
                <strong>Hőszigetelő acélbetétek:</strong> Minimális hőhidak
              </li>
              <li>
                <strong>7 kamrás szerkezet:</strong> Optimális hőszigetelés
              </li>
              <li>
                <strong>82 mm mélység:</strong> Maximális teljesítmény
              </li>
              <li>
                <strong>Prémium vasalatok:</strong> Siegenia TITAN AF HS
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4">Teljesítmény adatok</h3>
            <ul className="space-y-2">
              <li>
                <strong>Hőátbocsátás:</strong> Uw = 0,6 W/m²K
              </li>
              <li>
                <strong>Hangszigetelés:</strong> Rw = 42 dB
              </li>
              <li>
                <strong>Légáteresztés:</strong> Klasse 4
              </li>
              <li>
                <strong>Vízhatlanság:</strong> Klasse 9A
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-accent/10 p-8 rounded-lg mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6">🏆 Díjak és elismerések</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <Award className="h-16 w-16 text-accent mx-auto mb-4" />
            <h3 className="font-bold mb-2">Passzívház Intézet</h3>
            <p className="text-sm">Tanúsított komponens</p>
          </div>
          <div className="text-center">
            <Star className="h-16 w-16 text-accent mx-auto mb-4" />
            <h3 className="font-bold mb-2">Red Dot Design</h3>
            <p className="text-sm">Design díj 2023</p>
          </div>
          <div className="text-center">
            <Shield className="h-16 w-16 text-accent mx-auto mb-4" />
            <h3 className="font-bold mb-2">RAL Gütezeichen</h3>
            <p className="text-sm">Minőségi tanúsítvány</p>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-2xl font-bold text-primary mb-6">Tapasztalja meg a csúcstechnológiát!</h2>
        <Link href="/kapcsolat" className="btn-primary">
          Winergetic-82 árajánlat kérése
        </Link>
      </div>
    </div>
  )
}
