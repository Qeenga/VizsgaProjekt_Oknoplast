import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, CheckCircle, Thermometer, Shield, Home, Lock } from "lucide-react"

export default function MuanyagBejaratiAjtok() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link
          href="/termekeink"
          className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a termékekhez
        </Link>

        <div className="mb-6">
          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">BEJÁRATI AJTÓ</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Műanyag bejárati ajtók</h1>
        <p className="text-xl text-gray-700 mb-8">
          Kiváló hőszigetelési tulajdonságokkal rendelkező energiatakarékos megoldás
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        <div className="relative h-96 rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Műanyag+Bejárati+Ajtó"
            alt="Oknoplast műanyag bejárati ajtó"
            fill
            className="object-cover"
          />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-primary mb-4">Miért válassza a műanyag bejárati ajtót?</h2>
          <p className="mb-6">
            A műanyag bejárati ajtók tökéletes választást jelentenek azok számára, akik energiatakarékos,
            karbantartásmentes és biztonságos megoldást keresnek. A modern PVC profilok kiváló hőszigetelést
            biztosítanak, miközben hosszú élettartamot és esztétikus megjelenést garantálnak.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Kiváló hőszigetelés</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Karbantartásmentes</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>RC2 biztonsági osztály</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Időjárásálló</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Thermometer className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Hőszigetelés</h3>
          <p className="text-sm mb-2">Ud = 1,2 W/m²K</p>
          <p className="text-xs text-gray-600">Energiatakarékos</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Biztonság</h3>
          <p className="text-sm mb-2">RC2 osztály</p>
          <p className="text-xs text-gray-600">Alapvető védelem</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Lock className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Zárrendszer</h3>
          <p className="text-sm mb-2">3 pontos zár</p>
          <p className="text-xs text-gray-600">Megbízható zárás</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Home className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Alkalmazás</h3>
          <p className="text-sm mb-2">Családi házak</p>
          <p className="text-xs text-gray-600">Lakóépületek</p>
        </div>
      </div>

      <div className="bg-primary/10 p-8 rounded-lg mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6">Műszaki jellemzők</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-bold mb-4">Profil specifikációk</h3>
            <ul className="space-y-2">
              <li>
                <strong>Anyag:</strong> Többkamrás PVC profil
              </li>
              <li>
                <strong>Hőátbocsátás:</strong> Ud = 1,2 W/m²K
              </li>
              <li>
                <strong>Hangszigetelés:</strong> Rw = 35 dB
              </li>
              <li>
                <strong>Légáteresztés:</strong> Klasse 4
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4">Biztonsági jellemzők</h3>
            <ul className="space-y-2">
              <li>
                <strong>Biztonsági osztály:</strong> RC2
              </li>
              <li>
                <strong>Zárrendszer:</strong> 3 pontos zár
              </li>
              <li>
                <strong>Üvegezés:</strong> Biztonsági üveg
              </li>
              <li>
                <strong>Vasalat:</strong> Prémium minőségű
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-2xl font-bold text-primary mb-6">Kérjen árajánlatot műanyag bejárati ajtóra!</h2>
        <Link href="/kapcsolat" className="btn-primary">
          Ingyenes árajánlat kérése
        </Link>
      </div>
    </div>
  )
}
