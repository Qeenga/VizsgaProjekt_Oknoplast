import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, CheckCircle, Thermometer, Shield, Zap } from "lucide-react"

export default function Prolux70() {
  return (
    <div className="container-custom">
      <div className="mb-8">
        <Link
          href="/termekeink"
          className="inline-flex items-center text-primary hover:text-accent transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Vissza a termékekhez
        </Link>

        <div className="mb-6">
          <span className="bg-primary text-white px-3 py-1 rounded-full text-sm font-semibold">PRÉMIUM MŰANYAG</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Prolux-70</h1>
        <p className="text-xl text-gray-700 mb-8">
          Prémium 6 kamrás profilrendszer fokozott hőszigetelési tulajdonságokkal
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        <div className="relative h-96 rounded-lg overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=600&text=Prolux-70+Prémium+Ablak"
            alt="Oknoplast Prolux-70 prémium ablak"
            fill
            className="object-cover"
          />
        </div>

        <div>
          <h2 className="text-2xl font-bold text-primary mb-4">Prémium minőség minden részletben</h2>
          <p className="mb-6">
            A Prolux-70 a prémium kategória képviselője az Oknoplast kínálatában. A 6 kamrás profilszerkezet kiváló
            hőszigetelést biztosít, míg a modern design és a fokozott funkcionalitás teszi tökéletes választássá igényes
            otthonok számára.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>6 kamrás prémium profil</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Kiváló hőszigetelés</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Fokozott hangszigetelés</span>
            </div>
            <div className="flex items-start">
              <CheckCircle className="h-6 w-6 text-green-600 mr-2 mt-0.5" />
              <span>Modern design</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Thermometer className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Energiahatékonyság</h3>
          <p className="text-sm mb-2">Uw = 0,9 W/m²K</p>
          <p className="text-xs text-gray-600">Kiváló hőszigetelési tulajdonságok</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Hangszigetelés</h3>
          <p className="text-sm mb-2">Rw = 35 dB</p>
          <p className="text-xs text-gray-600">Fokozott zajvédelem</p>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg text-center">
          <Zap className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="font-bold text-lg mb-2">Funkcionalitás</h3>
          <p className="text-sm mb-2">Prémium vasalatok</p>
          <p className="text-xs text-gray-600">Könnyű kezelhetőség</p>
        </div>
      </div>

      <div className="bg-accent/10 p-8 rounded-lg mb-16">
        <h2 className="text-2xl font-bold text-primary mb-6">Prémium jellemzők</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-bold mb-4">Profil specifikációk</h3>
            <ul className="space-y-2">
              <li>
                <strong>Kamraszám:</strong> 6 kamra
              </li>
              <li>
                <strong>Beépítési mélység:</strong> 70 mm
              </li>
              <li>
                <strong>Hőátbocsátási tényező:</strong> Uw = 0,9 W/m²K
              </li>
              <li>
                <strong>Hangszigetelés:</strong> Rw = 35 dB
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-4">Prémium kiegészítők</h3>
            <ul className="space-y-2">
              <li>
                <strong>Vasalat:</strong> Siegenia TITAN AF HS
              </li>
              <li>
                <strong>Üvegezés:</strong> 4-16-4 mm Low-E
              </li>
              <li>
                <strong>Színválaszték:</strong> 20+ szín
              </li>
              <li>
                <strong>Mikroszellőzés:</strong> Opcionális
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-2xl font-bold text-primary mb-6">Tapasztalja meg a prémium minőséget!</h2>
        <Link href="/kapcsolat" className="btn-primary">
          Ingyenes konzultáció kérése
        </Link>
      </div>
    </div>
  )
}
