"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/lib/supabase/client"
import type { Product } from "@/lib/product-utils"
import { Trash2, Eye, Edit, Plus, Save, X, Upload } from "lucide-react"

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [products, setProducts] = useState<Product[]>([])
  const [files, setFiles] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [uploadingImage, setUploadingImage] = useState(false)
  const [bucketExists, setBucketExists] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<string>("")
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: "",
    description: "",
    category: "ablakok",
    price_range: "mid",
    specifications: {},
    image_src: "",
    link: "/kapcsolat",
    is_active: true,
    sort_order: 0,
  })

  useEffect(() => {
    const auth = localStorage.getItem("oknoplast_admin_auth")
    if (auth === "authenticated") {
      setIsAuthenticated(true)
      testConnection()
      checkAndCreateBucket()
      loadProducts()
      loadFiles()
    }
  }, [])

  const testConnection = async () => {
    try {
      setConnectionStatus("Kapcsolat tesztelése...")
      const supabase = createClient()
      const { data, error } = await supabase.from("products").select("count", { count: "exact" }).limit(1)

      if (error) {
        console.error("Connection test error:", error)
        setConnectionStatus(`Kapcsolati hiba: ${error.message}`)
      } else {
        setConnectionStatus("Kapcsolat sikeres")
        console.log("Connection successful, product count:", data)
      }
    } catch (error) {
      console.error("Connection test failed:", error)
      setConnectionStatus(`Kapcsolat sikertelen: ${(error as Error).message}`)
    }
  }

  const checkAndCreateBucket = async () => {
    try {
      const supabase = createClient()
      const { data: buckets, error: listError } = await supabase.storage.listBuckets()

      if (listError) {
        console.error("Error listing buckets:", listError)
        setBucketExists(false)
        return
      }

      const bucketExists = buckets?.some((bucket) => bucket.name === "oknoplast-images")
      setBucketExists(bucketExists || false)

      if (!bucketExists) {
        console.log("Bucket 'oknoplast-images' does not exist. Please create it manually or run the setup script.")
      } else {
        console.log("Bucket 'oknoplast-images' exists and is accessible")
      }
    } catch (error) {
      console.error("Error checking bucket:", error)
      setBucketExists(false)
    }
  }

  const handleLogin = () => {
    if (password === "oknoplast2024admin") {
      setIsAuthenticated(true)
      localStorage.setItem("oknoplast_admin_auth", "authenticated")
      testConnection()
      checkAndCreateBucket()
      loadProducts()
      loadFiles()
    } else {
      alert("Hibás jelszó!")
    }
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    localStorage.removeItem("oknoplast_admin_auth")
    setPassword("")
    setEditingProduct(null)
    setConnectionStatus("")
  }

  const loadProducts = async () => {
    setLoading(true)
    try {
      console.log("Loading products...")
      const supabase = createClient()
      const { data, error } = await supabase.from("products").select("*").order("sort_order")

      if (error) {
        console.error("Error loading products:", error)
        throw error
      }

      console.log("Products loaded:", data?.length || 0)
      setProducts(data || [])
    } catch (error) {
      console.error("Error loading products:", error)
      alert(`Hiba a termékek betöltése során: ${(error as Error).message}`)
    } finally {
      setLoading(false)
    }
  }

  const loadFiles = async () => {
    if (!bucketExists) return

    try {
      const supabase = createClient()
      const { data, error } = await supabase.storage.from("oknoplast-images").list("", {
        limit: 100,
        offset: 0,
      })

      if (error) {
        console.error("Error loading files:", error)
        return
      }

      const filesWithUrls = await Promise.all(
        (data || []).map(async (file) => {
          const { data: urlData } = supabase.storage.from("oknoplast-images").getPublicUrl(file.name)
          return {
            ...file,
            url: urlData.publicUrl,
          }
        }),
      )

      setFiles(filesWithUrls)
    } catch (error) {
      console.error("Error loading files:", error)
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (!bucketExists) {
      alert("A bucket még nem létezik. Kérem várjon...")
      return
    }

    setLoading(true)
    try {
      const fileExt = file.name.split(".").pop()
      const fileName = `${Date.now()}.${fileExt}`

      const supabase = createClient()
      const { error } = await supabase.storage.from("oknoplast-images").upload(fileName, file)

      if (error) throw error

      alert("Fájl sikeresen feltöltve!")
      loadFiles()
    } catch (error) {
      console.error("Error uploading file:", error)
      alert("Hiba a fájl feltöltése során: " + (error as Error).message)
    } finally {
      setLoading(false)
    }
  }

  const handleImageUploadForProduct = async (event: React.ChangeEvent<HTMLInputElement>, isEditing = false) => {
    const file = event.target.files?.[0]
    if (!file) return

    if (!bucketExists) {
      alert("A bucket még nem létezik. Kérem várjon...")
      return
    }

    setUploadingImage(true)
    try {
      const fileExt = file.name.split(".").pop()
      const fileName = `products/${Date.now()}.${fileExt}`

      const supabase = createClient()
      const { error } = await supabase.storage.from("oknoplast-images").upload(fileName, file)

      if (error) throw error

      const { data: urlData } = supabase.storage.from("oknoplast-images").getPublicUrl(fileName)
      const imageUrl = urlData.publicUrl

      if (isEditing && editingProduct) {
        setEditingProduct({ ...editingProduct, image_src: imageUrl })
      } else {
        setNewProduct({ ...newProduct, image_src: imageUrl })
      }

      alert("Kép sikeresen feltöltve!")
      loadFiles()
      const fileInput = document.getElementById(
        isEditing ? "edit-image-upload" : "new-image-upload",
      ) as HTMLInputElement
      if (fileInput) {
        fileInput.value = ""
      }
    } catch (error) {
      console.error("Error uploading image:", error)
      alert("Hiba a kép feltöltése során: " + (error as Error).message)
    } finally {
      setUploadingImage(false)
    }
  }

  const handleFileDelete = async (fileName: string) => {
    if (!confirm("Biztosan törli ezt a fájlt?")) return

    try {
      const supabase = createClient()
      const { error } = await supabase.storage.from("oknoplast-images").remove([fileName])

      if (error) throw error

      alert("Fájl sikeresen törölve!")
      loadFiles()
    } catch (error) {
      console.error("Error deleting file:", error)
      alert("Hiba a fájl törlése során")
    }
  }

  const handleProductSave = async () => {
    if (!editingProduct) return

    setLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.from("products").update(editingProduct).eq("id", editingProduct.id)

      if (error) throw error

      alert("Termék sikeresen mentve!")
      setEditingProduct(null)
      loadProducts()
    } catch (error) {
      console.error("Error saving product:", error)
      alert("Hiba a termék mentése során: " + (error as Error).message)
    } finally {
      setLoading(false)
    }
  }

  const handleProductCreate = async () => {
    setLoading(true)
    try {
      const supabase = createClient()
      const { error } = await supabase.from("products").insert([newProduct])

      if (error) throw error

      alert("Új termék sikeresen létrehozva!")
      setNewProduct({
        name: "",
        description: "",
        category: "ablakok",
        price_range: "mid",
        specifications: {},
        image_src: "",
        link: "/kapcsolat",
        is_active: true,
        sort_order: 0,
      })
      loadProducts()
    } catch (error) {
      console.error("Error creating product:", error)
      alert("Hiba az új termék létrehozása során: " + (error as Error).message)
    } finally {
      setLoading(false)
    }
  }

  const handleProductDelete = async (id: string) => {
    if (!confirm("Biztosan törli ezt a terméket?")) return

    try {
      const supabase = createClient()
      const { error } = await supabase.from("products").delete().eq("id", id)

      if (error) throw error

      alert("Termék sikeresen törölve!")
      loadProducts()
    } catch (error) {
      console.error("Error deleting product:", error)
      alert("Hiba a termék törlése során")
    }
  }

  const selectImageFromGallery = (imageUrl: string, isEditing = false) => {
    if (isEditing && editingProduct) {
      setEditingProduct({ ...editingProduct, image_src: imageUrl })
    } else {
      setNewProduct({ ...newProduct, image_src: imageUrl })
    }
  }

  const handleEditProduct = (product: Product) => {
    console.log("Editing product:", product)
    setEditingProduct(product)
  }

  const handleCancelEdit = () => {
    setEditingProduct(null)
  }

  const triggerFileInput = (inputId: string) => {
    const fileInput = document.getElementById(inputId) as HTMLInputElement
    if (fileInput) {
      fileInput.click()
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Admin Bejelentkezés</CardTitle>
            <CardDescription>Adja meg az admin jelszót a folytatáshoz</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="password">Jelszó</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleLogin()}
              />
            </div>
            <Button onClick={handleLogin} className="w-full">
              Bejelentkezés
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-primary">Oknoplast Admin</h1>
          <div className="flex items-center gap-4">
            {connectionStatus && (
              <Badge variant={connectionStatus.includes("sikeres") ? "default" : "destructive"}>
                {connectionStatus}
              </Badge>
            )}
            {!bucketExists && <Badge variant="destructive">Bucket nem létezik</Badge>}
            <Button onClick={handleLogout} variant="outline">
              Kijelentkezés
            </Button>
          </div>
        </div>

        <Tabs defaultValue="files" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="files">Fájlkezelő</TabsTrigger>
            <TabsTrigger value="products">Termékek</TabsTrigger>
            <TabsTrigger value="new-product">Új Termék</TabsTrigger>
          </TabsList>

          <TabsContent value="files" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Fájlkezelő</CardTitle>
                <CardDescription>Képek feltöltése és kezelése a Supabase storage-ban</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="file-upload">Új fájl feltöltése</Label>
                  <Input
                    id="file-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    disabled={loading || !bucketExists}
                  />
                  {!bucketExists && (
                    <p className="text-sm text-red-600 mt-1">A bucket még nem létezik vagy nem elérhető</p>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {files.map((file) => (
                    <Card key={file.name}>
                      <CardContent className="p-4">
                        <div className="aspect-video relative mb-2">
                          <img
                            src={file.url || "/placeholder.svg"}
                            alt={file.name}
                            className="w-full h-full object-cover rounded"
                          />
                        </div>
                        <p className="text-sm font-medium truncate mb-2">{file.name}</p>
                        <p className="text-xs text-gray-500 mb-2 break-all">{file.url}</p>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => navigator.clipboard.writeText(file.url)}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleFileDelete(file.name)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="space-y-4">
            {!editingProduct ? (
              <Card>
                <CardHeader>
                  <CardTitle>Termékek kezelése</CardTitle>
                  <CardDescription>Meglévő termékek szerkesztése és törlése</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <Button onClick={loadProducts} disabled={loading}>
                      {loading ? "Betöltés..." : "Termékek újratöltése"}
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {products.map((product) => (
                      <Card key={product.id} className="hover:shadow-lg transition-shadow">
                        <CardContent className="p-4">
                          <div className="aspect-video relative mb-2">
                            <img
                              src={product.image_src || "/placeholder.svg"}
                              alt={product.name}
                              className="w-full h-full object-cover rounded"
                            />
                          </div>
                          <h3 className="font-semibold mb-1">{product.name}</h3>
                          <p className="text-sm text-gray-600 mb-2 line-clamp-2">{product.description}</p>
                          <div className="flex gap-1 mb-2 flex-wrap">
                            <Badge variant="secondary">{product.category}</Badge>
                            <Badge variant="outline">{product.price_range}</Badge>
                            {product.is_active ? (
                              <Badge className="bg-green-100 text-green-800">Aktív</Badge>
                            ) : (
                              <Badge variant="destructive">Inaktív</Badge>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => handleEditProduct(product)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="destructive" onClick={() => handleProductDelete(product.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Termék szerkesztése: {editingProduct.name}</CardTitle>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={handleProductSave} disabled={loading}>
                      <Save className="w-4 h-4 mr-2" />
                      {loading ? "Mentés..." : "Mentés"}
                    </Button>
                    <Button size="sm" variant="outline" onClick={handleCancelEdit}>
                      <X className="w-4 h-4 mr-2" />
                      Mégse
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Termék neve</Label>
                      <Input
                        value={editingProduct.name}
                        onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label>Kategória</Label>
                      <Select
                        value={editingProduct.category}
                        onValueChange={(value) => setEditingProduct({ ...editingProduct, category: value as any })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ablakok">Ablakok</SelectItem>
                          <SelectItem value="ajtok">Ajtók</SelectItem>
                          <SelectItem value="redonyok">Redőnyök</SelectItem>
                          <SelectItem value="accessories">Kiegészítők</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Árkategória</Label>
                      <Select
                        value={editingProduct.price_range}
                        onValueChange={(value) => setEditingProduct({ ...editingProduct, price_range: value as any })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="budget">Alapvető</SelectItem>
                          <SelectItem value="mid">Közép</SelectItem>
                          <SelectItem value="premium">Prémium</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Link</Label>
                      <Input
                        value={editingProduct.link || ""}
                        onChange={(e) => setEditingProduct({ ...editingProduct, link: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Label>Termék kép</Label>
                    <div className="flex gap-4 items-start">
                      <div className="flex-1">
                        <Input
                          value={editingProduct.image_src || ""}
                          onChange={(e) => setEditingProduct({ ...editingProduct, image_src: e.target.value })}
                          placeholder="Kép URL"
                        />
                      </div>
                      <div className="flex gap-2">
                        <div className="relative">
                          <Input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageUploadForProduct(e, true)}
                            className="hidden"
                            id="edit-image-upload"
                            disabled={uploadingImage || !bucketExists}
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => triggerFileInput("edit-image-upload")}
                            disabled={uploadingImage || !bucketExists}
                          >
                            <Upload className="w-4 h-4 mr-2" />
                            {uploadingImage ? "Feltöltés..." : "Feltöltés"}
                          </Button>
                        </div>
                      </div>
                    </div>

                    {editingProduct.image_src && (
                      <div className="w-32 h-32 relative border rounded">
                        <img
                          src={editingProduct.image_src || "/placeholder.svg"}
                          alt="Termék kép"
                          className="w-full h-full object-cover rounded"
                        />
                      </div>
                    )}

                    {bucketExists && files.length > 0 && (
                      <div>
                        <Label>Vagy válasszon a galériából:</Label>
                        <div className="grid grid-cols-4 md:grid-cols-6 gap-2 mt-2 max-h-40 overflow-y-auto">
                          {files.map((file) => (
                            <div
                              key={file.name}
                              className="aspect-square relative cursor-pointer border-2 border-transparent hover:border-primary rounded"
                              onClick={() => selectImageFromGallery(file.url, true)}
                            >
                              <img
                                src={file.url || "/placeholder.svg"}
                                alt={file.name}
                                className="w-full h-full object-cover rounded"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <Label>Leírás</Label>
                    <Textarea
                      value={editingProduct.description}
                      onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label>Műszaki adatok (JSON formátum)</Label>
                    <Textarea
                      value={JSON.stringify(editingProduct.specifications || {}, null, 2)}
                      onChange={(e) => {
                        try {
                          const specs = JSON.parse(e.target.value)
                          setEditingProduct({ ...editingProduct, specifications: specs })
                        } catch (error) {
                          // Invalid JSON, don't update
                        }
                      }}
                      rows={4}
                      placeholder='{"Uw": "1,1 W/m²K", "Kamraszám": "5 kamrás"}'
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="is-active-edit"
                      checked={editingProduct.is_active}
                      onChange={(e) => setEditingProduct({ ...editingProduct, is_active: e.target.checked })}
                    />
                    <Label htmlFor="is-active-edit">Aktív termék</Label>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="new-product" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Új termék létrehozása</CardTitle>
                <CardDescription>Új termék hozzáadása az adatbázishoz</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Termék neve</Label>
                    <Input
                      value={newProduct.name}
                      onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Kategória</Label>
                    <Select
                      value={newProduct.category}
                      onValueChange={(value) => setNewProduct({ ...newProduct, category: value as any })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ablakok">Ablakok</SelectItem>
                        <SelectItem value="ajtok">Ajtók</SelectItem>
                        <SelectItem value="redonyok">Redőnyök</SelectItem>
                        <SelectItem value="accessories">Kiegészítők</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Árkategória</Label>
                    <Select
                      value={newProduct.price_range}
                      onValueChange={(value) => setNewProduct({ ...newProduct, price_range: value as any })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="budget">Alapvető</SelectItem>
                        <SelectItem value="mid">Közép</SelectItem>
                        <SelectItem value="premium">Prémium</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Link</Label>
                    <Input
                      value={newProduct.link}
                      onChange={(e) => setNewProduct({ ...newProduct, link: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <Label>Termék kép</Label>
                  <div className="flex gap-4 items-start">
                    <div className="flex-1">
                      <Input
                        value={newProduct.image_src}
                        onChange={(e) => setNewProduct({ ...newProduct, image_src: e.target.value })}
                        placeholder="Kép URL"
                      />
                    </div>
                    <div className="flex gap-2">
                      <div className="relative">
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUploadForProduct(e, false)}
                          className="hidden"
                          id="new-image-upload"
                          disabled={uploadingImage || !bucketExists}
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => triggerFileInput("new-image-upload")}
                          disabled={uploadingImage || !bucketExists}
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          {uploadingImage ? "Feltöltés..." : "Feltöltés"}
                        </Button>
                      </div>
                    </div>
                  </div>

                  {newProduct.image_src && (
                    <div className="w-32 h-32 relative border rounded">
                      <img
                        src={newProduct.image_src || "/placeholder.svg"}
                        alt="Termék kép"
                        className="w-full h-full object-cover rounded"
                      />
                    </div>
                  )}

                  {bucketExists && files.length > 0 && (
                    <div>
                      <Label>Vagy válasszon a galériából:</Label>
                      <div className="grid grid-cols-4 md:grid-cols-6 gap-2 mt-2 max-h-40 overflow-y-auto">
                        {files.map((file) => (
                          <div
                            key={file.name}
                            className="aspect-square relative cursor-pointer border-2 border-transparent hover:border-primary rounded"
                            onClick={() => selectImageFromGallery(file.url, false)}
                          >
                            <img
                              src={file.url || "/placeholder.svg"}
                              alt={file.name}
                              className="w-full h-full object-cover rounded"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label>Leírás</Label>
                  <Textarea
                    value={newProduct.description}
                    onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                    rows={3}
                  />
                </div>

                <div>
                  <Label>Műszaki adatok (JSON formátum)</Label>
                  <Textarea
                    value={JSON.stringify(newProduct.specifications || {}, null, 2)}
                    onChange={(e) => {
                      try {
                        const specs = JSON.parse(e.target.value)
                        setNewProduct({ ...newProduct, specifications: specs })
                      } catch (error) {
                        // Invalid JSON, don't update
                      }
                    }}
                    rows={4}
                    placeholder='{"Uw": "1,1 W/m²K", "Kamraszám": "5 kamrás"}'
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="is-active-new"
                    checked={newProduct.is_active}
                    onChange={(e) => setNewProduct({ ...newProduct, is_active: e.target.checked })}
                  />
                  <Label htmlFor="is-active-new">Aktív termék</Label>
                </div>

                <Button onClick={handleProductCreate} disabled={loading || !bucketExists}>
                  <Plus className="w-4 h-4 mr-2" />
                  {loading ? "Létrehozás..." : "Termék létrehozása"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
