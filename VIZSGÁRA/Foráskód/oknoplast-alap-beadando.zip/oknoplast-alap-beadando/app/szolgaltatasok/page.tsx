import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import ContactCTA from "@/components/contact-cta"
import { Wrench, Truck, Shield, Clock, CheckCircle, Users, Award, Phone, MapPin, Calendar, Star } from "lucide-react"
import Link from "next/link"

const services = [
  {
    title: "Ingyenes Helyszíni Felmérés",
    description: "Szakértő csapatunk ingyenesen felméri otthonát és személyre szabott ajánlatot készít.",
    icon: MapPin,
    features: ["Pontos méretfelvétel", "Helyszíni tanácsadás", "Költségmentes ajánlat", "Gyors időpontfoglalás"],
    badge: "Ingyenes",
    color: "bg-green-50 border-green-200",
  },
  {
    title: "Professzionális Beépítés",
    description: "Tapasztalt szerelőink gondoskodnak a szakszerű és precíz beépítésről.",
    icon: Wrench,
    features: ["Szakképzett szerelők", "Precíz munkavégzés", "Tiszta munkaterület", "Minőségi kivitelezés"],
    badge: "Szakértelem",
    color: "bg-blue-50 border-blue-200",
  },
  {
    title: "Szállítás és Logisztika",
    description: "Gondoskodunk a termékek biztonságos szállításáról és időben történő kiszállításáról.",
    icon: Truck,
    features: ["Pontos szállítás", "Biztonságos csomagolás", "Rugalmas időpontok", "Országos kiszállítás"],
    badge: "Megbízható",
    color: "bg-purple-50 border-purple-200",
  },
  {
    title: "Hosszú Távú Garancia",
    description: "Minden termékünkre és szolgáltatásunkra kiterjedő, hosszú távú garanciát vállalunk.",
    icon: Shield,
    features: ["10 év termékgarancia", "2 év szerelési garancia", "Gyors hibaelhárítás", "Ingyenes karbantartás"],
    badge: "Garancia",
    color: "bg-orange-50 border-orange-200",
  },
  {
    title: "Gyors Ügyintézés",
    description: "Hatékony folyamatainknak köszönhetően gyorsan és zökkenőmentesen intézzük megrendelését.",
    icon: Clock,
    features: ["24 órás ajánlat", "Gyors szerelési időpont", "Online nyomon követés", "Rugalmas fizetés"],
    badge: "Gyors",
    color: "bg-red-50 border-red-200",
  },
  {
    title: "Ügyfélszolgálat",
    description: "Kiváló ügyfélszolgálatunk minden lépésben támogatja Önt a vásárlási folyamat során.",
    icon: Users,
    features: ["Személyes tanácsadás", "Telefonos támogatás", "Email kapcsolat", "Utógondozás"],
    badge: "Támogatás",
    color: "bg-teal-50 border-teal-200",
  },
]

const process = [
  {
    step: 1,
    title: "Kapcsolatfelvétel",
    description: "Vegye fel velünk a kapcsolatot telefonon, emailben vagy személyesen.",
    icon: Phone,
  },
  {
    step: 2,
    title: "Helyszíni Felmérés",
    description: "Ingyenes helyszíni felméréssel pontos ajánlatot készítünk.",
    icon: MapPin,
  },
  {
    step: 3,
    title: "Ajánlat és Megrendelés",
    description: "Részletes ajánlat alapján leadhatja megrendelését.",
    icon: CheckCircle,
  },
  {
    step: 4,
    title: "Gyártás és Szállítás",
    description: "Termékek legyártása és pontos időben történő kiszállítása.",
    icon: Truck,
  },
  {
    step: 5,
    title: "Professzionális Beépítés",
    description: "Szakképzett csapatunk gondoskodik a precíz beépítésről.",
    icon: Wrench,
  },
  {
    step: 6,
    title: "Átadás és Garancia",
    description: "Munkák átadása és hosszú távú garancia biztosítása.",
    icon: Award,
  },
]

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Szolgáltatásaink</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Az Oknoplast Debrecen teljes körű szolgáltatást nyújt a tervezéstől a beépítésig. Tapasztalt csapatunk
              minden lépésben támogatja Önt.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Miért válasszon minket?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Több mint 15 éves tapasztalattal és több ezer elégedett ügyféllel a háta mögött, az Oknoplast Debrecen
              garantálja a minőségi szolgáltatást.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon
              return (
                <Card key={index} className={`${service.color} hover:shadow-lg transition-shadow`}>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <IconComponent className="w-12 h-12 text-primary" />
                      <Badge variant="secondary">{service.badge}</Badge>
                    </div>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                    <CardDescription className="text-gray-600">{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {service.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className="flex items-center text-sm">
                          <CheckCircle className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Hogyan dolgozunk?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Hat egyszerű lépésben juthat el az álmai ablakaihoz és ajtóihoz. Minden folyamat átlátható és ügyfélbarát.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {process.map((step, index) => {
              const IconComponent = step.icon
              return (
                <div key={index} className="text-center">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="w-8 h-8" />
                    </div>
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-accent text-primary rounded-full flex items-center justify-center font-bold text-sm">
                      {step.step}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-primary mb-3">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Quality Assurance */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Minőségbiztosítás</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Minden munkánkat szigorú minőségi követelmények szerint végezzük, hogy Ön hosszú távon elégedett legyen.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">Minősített Szerelők</h3>
              <p className="text-gray-600 text-sm">Minden szerelőnk rendelkezik megfelelő képesítéssel</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">Prémium Anyagok</h3>
              <p className="text-gray-600 text-sm">Csak a legjobb minőségű alapanyagokat használjuk</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">Minőségi Ellenőrzés</h3>
              <p className="text-gray-600 text-sm">Minden munkafázist alaposan ellenőrzünk</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">Időben Teljesítés</h3>
              <p className="text-gray-600 text-sm">Minden határidőt pontosan betartunk</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Készen áll az első lépésre?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Kérjen ingyenes helyszíni felmérést és személyre szabott ajánlatot még ma!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/kapcsolat">Ingyenes Felmérés</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-white text-white hover:bg-white hover:text-primary"
              asChild
            >
              <Link href="tel:+36301234567">Hívjon Most</Link>
            </Button>
          </div>
        </div>
      </section>

      <ContactCTA />
    </div>
  )
}
