import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import ContactCTA from "@/components/contact-cta"
import { Users, Award, Clock, CheckCircle, Star, Heart, Shield, Lightbulb, Target } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const stats = [
  { number: "15+", label: "Év Tapasztalat", icon: Clock },
  { number: "5000+", label: "Elégedett Ügyfél", icon: Users },
  { number: "10000+", label: "Beépített Ablak", icon: Award },
  { number: "100%", label: "Elégedettség", icon: Star },
]

const values = [
  {
    title: "Minőség",
    description: "Csak a legmagasabb minőségű anyagokat és technológiákat használjuk.",
    icon: Award,
    color: "bg-blue-50 border-blue-200",
  },
  {
    title: "Megbízhatóság",
    description: "Minden ígéretünket betartjuk, minden határidőt pontosan teljesítünk.",
    icon: Shield,
    color: "bg-green-50 border-green-200",
  },
  {
    title: "Innováció",
    description: "Folyamatosan követjük a legújabb technológiai fejlesztéseket.",
    icon: Lightbulb,
    color: "bg-yellow-50 border-yellow-200",
  },
  {
    title: "Ügyfélközpontúság",
    description: "Minden döntésünk középpontjában ügyfeleink elégedettsége áll.",
    icon: Heart,
    color: "bg-red-50 border-red-200",
  },
]

const team = [
  {
    name: "Nagy Péter",
    position: "Ügyvezető",
    description: "15 éves tapasztalattal az ablak- és ajtóiparban. Személyesen felügyeli minden projekt minőségét.",
    image: "/placeholder.svg?height=300&width=300&text=Nagy+Péter",
  },
  {
    name: "Kovács Anna",
    position: "Értékesítési Vezető",
    description: "Szakértő tanácsadó, aki segít megtalálni a tökéletes megoldást minden ügyfél számára.",
    image: "/placeholder.svg?height=300&width=300&text=Kovács+Anna",
  },
  {
    name: "Szabó Gábor",
    position: "Műszaki Vezető",
    description: "Tapasztalt szerelő, aki gondoskodik a precíz és szakszerű beépítésről.",
    image: "/placeholder.svg?height=300&width=300&text=Szabó+Gábor",
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Rólunk</h1>
              <p className="text-xl mb-8">
                Az Oknoplast Debrecen több mint 15 éve szolgálja ki ügyfeleit a legmagasabb minőségű műanyag ablakok,
                ajtók és redőnyök területén. Tapasztalt csapatunk és megbízható partnereink garantálják, hogy Ön a
                legjobb megoldást kapja.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" variant="secondary" asChild>
                  <Link href="/kapcsolat">Kapcsolat</Link>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-transparent border-white text-white hover:bg-white hover:text-primary"
                  asChild
                >
                  <Link href="/termekeink">Termékeink</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/images/oknoplast-group-1.png"
                alt="Oknoplast csapat"
                width={500}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const IconComponent = stat.icon
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-primary mb-6">Történetünk</h2>
              <div className="space-y-4 text-gray-600">
                <p>
                  Az Oknoplast Debrecen 2008-ban kezdte meg működését azzal a céllal, hogy Debrecen és környékének lakói
                  számára a legmagasabb minőségű ablak- és ajtómegoldásokat biztosítsa.
                </p>
                <p>
                  Az évek során folyamatosan bővítettük szolgáltatásainkat és termékpalettánkat. Ma már nemcsak műanyag
                  ablakokat és ajtókat, hanem redőnyöket, pergolát és minden kapcsolódó kiegészítőt is kínálunk.
                </p>
                <p>
                  Büszkék vagyunk arra, hogy több mint 5000 elégedett ügyfél választotta már szolgáltatásainkat, és
                  folyamatosan dolgozunk azon, hogy még jobb megoldásokat kínáljunk.
                </p>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/images/okna-dom-parterowy-oknoplast.jpg"
                alt="Oknoplast referencia ház"
                width={500}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Értékeink</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Ezek az alapelvek vezérelnek minket minden nap, minden projektben és minden ügyfélkapcsolatban.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon
              return (
                <Card key={index} className={`${value.color} hover:shadow-lg transition-shadow text-center`}>
                  <CardHeader>
                    <IconComponent className="w-12 h-12 text-primary mx-auto mb-4" />
                    <CardTitle className="text-xl">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">{value.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-primary mb-4">Csapatunk</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Tapasztalt szakembereink minden lépésben támogatják Önt, a tervezéstől a beépítésig.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center">
                  <div className="w-32 h-32 mx-auto mb-4 relative">
                    <Image
                      src={member.image || "/placeholder.svg"}
                      alt={member.name}
                      fill
                      className="rounded-full object-cover"
                    />
                  </div>
                  <CardTitle className="text-xl">{member.name}</CardTitle>
                  <Badge variant="secondary">{member.position}</Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm text-center">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <Target className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl font-bold mb-6">Küldetésünk</h2>
            <p className="text-xl max-w-3xl mx-auto mb-8">
              Célunk, hogy minden ügyfelünk számára a tökéletes ablak- és ajtómegoldást biztosítsuk, amely ötvözi a
              modern technológiát, a kiváló minőséget és a megfizethető árakat. Hiszünk abban, hogy minden otthon
              megérdemli a legjobbat.
            </p>
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              <div className="text-center">
                <CheckCircle className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-lg font-bold mb-2">Minőség</h3>
                <p className="text-sm opacity-90">Csak a legjobb anyagokat használjuk</p>
              </div>
              <div className="text-center">
                <CheckCircle className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-lg font-bold mb-2">Szolgáltatás</h3>
                <p className="text-sm opacity-90">Teljes körű ügyfélszolgálat</p>
              </div>
              <div className="text-center">
                <CheckCircle className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-lg font-bold mb-2">Garancia</h3>
                <p className="text-sm opacity-90">Hosszú távú garancia minden munkára</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </div>
  )
}
