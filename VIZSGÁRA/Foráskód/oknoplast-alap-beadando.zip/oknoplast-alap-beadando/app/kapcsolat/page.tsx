"use client"

import type React from "react"

import { useState } from "react"
import { MapPin, Phone, Mail, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      console.log("Email would be sent to: kovachkiinga@gmail.com")
      console.log("Form data:", formData)
      setSubmitSuccess(true)
      setIsSubmitting(false)
      setFormData({ name: "", email: "", phone: "", message: "" })

      // Hide success message after 5 seconds
      setTimeout(() => setSubmitSuccess(false), 5000)
    }, 1000)
  }

  return (
    <div className="container-custom">
      <h1 className="section-title mb-8 md:mb-12">Kapcsolat</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 mb-12">
        <div className="contact-info">
          <h2 className="text-xl md:text-2xl font-bold text-[#003366] mb-6">Elérhetőségek</h2>

          <div className="space-y-6">
            <div className="flex items-start">
              <MapPin className="h-6 w-6 text-[#003366] mr-4 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#003366] mb-1">Címünk</h3>
                <p className="text-gray-700">
                  4028 Debrecen
                  <br />
                  Hadházi út 1-3
                </p>
              </div>
            </div>

            <div className="flex items-start">
              <Phone className="h-6 w-6 text-[#003366] mr-4 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#003366] mb-1">Telefon</h3>
                <a href="tel:+36301234567" className="text-gray-700 hover:text-[#003366] transition-colors">
                  +36 30 123 4567
                </a>
              </div>
            </div>

            <div className="flex items-start">
              <Mail className="h-6 w-6 text-[#003366] mr-4 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#003366] mb-1">E-mail</h3>
                <a
                  href="mailto:kovachkiinga@gmail.com"
                  className="text-gray-700 hover:text-[#003366] transition-colors"
                >
                  kovachkiinga@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-start">
              <Clock className="h-6 w-6 text-[#003366] mr-4 mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-[#003366] mb-1">Nyitvatartás</h3>
                <div className="text-gray-700 space-y-1">
                  <p>Hétfő - Péntek: 8:00 - 17:00</p>
                  <p>Szombat: 9:00 - 13:00</p>
                  <p>Vasárnap: Zárva</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="contact-map">
          <h2 className="text-sm md:text-base font-bold text-[#003366] mb-6">Térképen</h2>
          <div className="w-full h-[250px] md:h-[400px] bg-gray-200 rounded-lg overflow-hidden">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2721.8!2d21.6262593!3d47.5415454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47470de69ff0cc63%3A0x8556c90655e48291!2sOknoplast%20M%C5%B1anyag%20Ablakok!5e0!3m2!1shu!2shu!4v1619705234567!5m2!1shu!2shu"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Oknoplast Debrecen térkép"
            />
          </div>
          <div className="mt-4">
            <a
              href="https://www.google.com/maps/place/Oknoplast+M%C5%B1anyag+Ablakok/@47.5415454,21.6236844,17z/data=!3m1!4b1!4m6!3m5!1s0x47470de69ff0cc63:0x8556c90655e48291!8m2!3d47.5415454!4d21.6262593!16s%2Fg%2F1v_s4pc_?entry=ttu&g_ep=EgoyMDI1MDgxOS4wIKXMDSoASAFQAw%3D%3D"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
            >
              <MapPin className="h-4 w-4 mr-2" />
              Útvonaltervező megnyitása
            </a>
          </div>
        </div>
      </div>

      <div className="contact-container">
        <div className="contact-form">
          <h2 className="text-sm md:text-base font-bold text-[#003366] mb-6">Küldjön üzenetet</h2>

          {submitSuccess && (
            <div className="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
              Köszönjük üzenetét! Hamarosan felvesszük Önnel a kapcsolatot.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                  Név *
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-transparent transition-colors"
                  placeholder="Az Ön neve"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  E-mail cím *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-transparent transition-colors"
                  placeholder="pelda@email.com"
                />
              </div>
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                Telefonszám
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-transparent transition-colors"
                placeholder="+36 30 123 4567"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                Üzenet *
              </label>
              <Textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleInputChange}
                required
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-transparent transition-colors resize-none"
                placeholder="Írja le kérését, kérdését..."
              />
            </div>

            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full md:w-auto bg-[#003366] hover:bg-[#002244] text-white px-8 py-3 rounded-lg font-semibold transition-colors disabled:opacity-50"
            >
              {isSubmitting ? "Küldés..." : "Üzenet küldése"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
