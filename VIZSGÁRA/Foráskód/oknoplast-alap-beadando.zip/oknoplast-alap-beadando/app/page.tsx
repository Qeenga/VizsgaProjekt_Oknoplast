import Hero from "@/components/hero"
import Introduction from "@/components/introduction"
import ProductsPreview from "@/components/products-preview"
import ServicesPreview from "@/components/services-preview"
import Testimonials from "@/components/testimonials"
import ContactCTA from "@/components/contact-cta"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Hero />
      <Introduction />
      <ProductsPreview />
      <ServicesPreview />
      <Testimonials />
      <ContactCTA />
    </div>
  )
}
