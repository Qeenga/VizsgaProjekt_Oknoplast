import { createClient } from "@/lib/supabase/server"

export interface Product {
  id: string
  name: string
  description: string
  category: string
  price_range: string
  image_src: string
  link: string
  specifications: Record<string, any>
  is_active: boolean
  sort_order: number
  created_at: string
  updated_at: string
}

export async function getProducts(): Promise<Product[]> {
  const supabase = await createClient()

  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("is_active", true)
    .order("sort_order", { ascending: true })

  if (error) {
    console.error("Error fetching products:", error)
    return []
  }

  return data || []
}

export async function getProductByLink(link: string): Promise<Product | null> {
  const supabase = await createClient()

  const { data, error } = await supabase.from("products").select("*").eq("link", link).eq("is_active", true).single()

  if (error) {
    console.error("Error fetching product:", error)
    return null
  }

  return data
}

export function formatPrice(priceRange: string): string {
  return priceRange || "Árajánlat kérésre"
}

export function getProductCategories(products: Product[]): string[] {
  const categories = new Set(products.map((p) => p.category))
  return Array.from(categories)
}
